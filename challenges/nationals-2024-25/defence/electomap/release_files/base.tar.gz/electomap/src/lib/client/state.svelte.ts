export const userState = $state({
	authenticated: false
});
