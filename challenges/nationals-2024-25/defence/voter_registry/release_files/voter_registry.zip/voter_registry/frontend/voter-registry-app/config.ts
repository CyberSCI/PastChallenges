export const API_BASE_URL = "https://api.register.valverde.vote";
export const KEYCLOAK_URL = "https://auth.register.valverde.vote";