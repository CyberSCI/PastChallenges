namespace VoterRegistryApi.Dtos
{
    public class AdvisoryDto
    {
        public string Message { get; set; } = string.Empty;

        public string? Url { get; set; } = null;
    }
}