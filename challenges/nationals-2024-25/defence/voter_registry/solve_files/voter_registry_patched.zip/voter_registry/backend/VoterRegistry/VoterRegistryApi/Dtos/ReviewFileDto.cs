namespace VoterRegistryApi.Dtos
{
    public class ReviewFileDto
    {
        public bool Approved { get; set; }
    }
}