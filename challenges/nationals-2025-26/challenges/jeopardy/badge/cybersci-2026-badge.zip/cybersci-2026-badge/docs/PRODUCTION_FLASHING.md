# CyberSci 2026 Badge — Production Flashing Runbook

Final firmware. Flash every badge with **mass-erase + APPROTECT lock**; mainframes
also get a **node index** baked into UICR (no console step). Lock is bundled into
the flash command and is the last operation, so there's nothing to remember.

## Prereqs (once)
- FT2232H FTDI adapter wired to the badge SWD header (P1: pin1 SWDIO, pin2 SWDCLK,
  pin5 GND; plus the ADBUS2 readback wire). `lsusb` shows `0403:6010`.
- Badge powered by its own USB-C/battery (the FTDI does not power it).
- Build artifacts present (rebuild if source changed):
  ```
  firmware/tools/badge-build.sh        # player    -> ~/badgebuild/zephyr/zephyr.hex
  firmware/tools/mainframe-build.sh    # mainframe -> ~/mainframebuild/zephyr/zephyr.hex
  ```

## Flash the 10 mainframes
One per organizer badge, each a **distinct** node 0–9:
```
firmware/tools/flash-mainframe.sh <0-9>
```
| node | system | | node | system |
|---|---|---|---|---|
| 0 | WOPR | | 5 | AS/400 |
| 1 | THE GIBSON | | 6 | IRIX |
| 2 | SETEC ASTRONOMY | | 7 | MIRAI |
| 3 | ORACLE | | 8 | NETGEAR |
| 4 | VAX | | 9 | SAP |

After each: power-cycle and confirm in **nRF Connect** that it advertises the
expected name (e.g. `firmware/tools/flash-mainframe.sh 3` → advertises `ORACLE`). That's the
post-lock functional check (BLE still works when locked).

## Flash the player badges
Every player badge is identical (self-IDs from chip UID):
```
firmware/tools/flash-player.sh
```
Smoke test: power on → "2026" fades in dim → LEDs blink Morse → set DIP to
`00011010` → console unlocks and prints `CyberSci{L4ST_C0NTACT_DE_SK}` + channel card.

## If a badge is bad / needs re-flashing (locked recovery)
Locking blocks normal SWD. To re-open (wipes the whole chip):
```
firmware/tools/badge-recover.sh
# power-cycle, then re-run the appropriate flash-*.sh
```

## Notes
- **Lock is reversible** but only via `badge-recover.sh` (full erase). Do all
  testing on the bench firmware *before* a production run; the production flash
  can't be inspected over SWD afterward.
- Locking does **not** affect gameplay — USB console, BLE GATT, and the Ch3
  broadcast all keep working. It only blocks debugger extraction of
  fragments/passwords/flags.
- Mainframe node identity lives in `UICR.CUSTOMER[0]`; recovery erases it, so a
  re-flash must re-pass `--node` (the wrapper does).
- Flags (all static, same for every badge): Ch1 `CyberSci{L4ST_C0NTACT_DE_SK}`,
  Ch2 `CyberSci{D34D_TR4NSM1SS10N}`, Ch3 `CyberSci{N0W_BR04DC4ST1NG_0N_4LL_CH4NN3LS}`.
