#!/usr/bin/env python3
"""
CyberSci 2026 — Ch3 "Numbers Station" helper / organizer solver.

The player badge broadcasts a numbers station in its BLE advertising, framed
[company 0x1337][seq][total][5 digits], each frame one 5-digit ciphertext group
(seq 0..total-1). Capture a full cycle, order by seq, concatenate the groups ->
the ciphertext digit string. Decode with the badge's per-badge key group (shown
on its channel card / `status`):

    plain_digit = (cipher_digit - key_digit) mod 10     (no borrow)
    then read the recovered digits in 3s as decimal ASCII codes -> flag.

Same convention as the Cuban "Atencion" station / Cuban Five case (encipher by
mod-10 addition, decipher by subtraction). Mirrors the firmware exactly, so it
doubles as a self-test that the on-badge encipher round-trips.
"""
import sys

MASK = (1 << 64) - 1
PAD_LEN = 8
B36 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"


def key_group(uid: int):
    """Per-badge repeating key digits, mixed from the UID (matches firmware)."""
    x = uid ^ 0x9E3779B97F4A7C15
    pad = []
    for _ in range(PAD_LEN):
        x = (x * 6364136223846793005 + 1442695040888963407) & MASK
        pad.append((x >> 59) % 10)
    return pad


def callsign(uid: int) -> str:
    y = uid ^ 0xD1B54A32D192ED03
    out = []
    for _ in range(4):
        y = (y * 6364136223846793005 + 1) & MASK
        out.append(B36[(y >> 58) % 36])
    return "".join(out)


def encipher(flag: str, pad) -> str:
    """flag char -> 3-digit ASCII -> plus key (mod 10). (firmware side)"""
    out, p = [], 0
    for ch in flag:
        c = ord(ch)
        for d in (c // 100 % 10, c // 10 % 10, c % 10):
            k = pad[p % PAD_LEN]
            out.append(str((d + k) % 10))
            p += 1
    return "".join(out)


def decode(cipher_digits: str, pad) -> str:
    """cipher digit string + key group -> flag."""
    plain = []
    for i, cd in enumerate(cipher_digits):
        k = pad[i % PAD_LEN]
        plain.append(str((int(cd) - k) % 10))
    digits = "".join(plain)
    chars = []
    for i in range(0, len(digits) - len(digits) % 3, 3):
        chars.append(chr(int(digits[i:i + 3])))
    return "".join(chars)


def main():
    flag = "CyberSci{N0W_BR04DC4ST1NG_0N_4LL_CH4NN3LS}"

    # Self-test against this bench board's known UID (see memory).
    uid = 0xDE66676A66CEC496
    pad = key_group(uid)
    cs = callsign(uid)
    cipher = encipher(flag, pad)
    back = decode(cipher, pad)

    print("=== self-test (bench UID 0x%016x) ===" % uid)
    print("  callsign  :", cs)
    print("  key group :", " ".join(str(d) for d in pad))
    print("  cipher    :", cipher)
    print("  decoded   :", back)
    print("  round-trip:", "OK" if back == flag else "*** MISMATCH ***")

    # CLI use: ch3_solve.py "<cipher digits>" "<key digits, spaces ok>"
    if len(sys.argv) == 3:
        cap = "".join(c for c in sys.argv[1] if c.isdigit())
        kd = [int(c) for c in sys.argv[2] if c.isdigit()]
        print("\n=== decode from capture ===")
        print("  flag:", decode(cap, kd))

    return 0 if back == flag else 1


if __name__ == "__main__":
    sys.exit(main())
