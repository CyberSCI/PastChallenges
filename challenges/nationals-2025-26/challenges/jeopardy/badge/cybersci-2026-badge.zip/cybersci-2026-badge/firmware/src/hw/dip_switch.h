#pragma once
#include <stdint.h>

/*
 * Bit N of the returned value corresponds to DIP switch N (0-indexed from
 * the schematic's pin P1.01 = bit 0). A bit is 1 when the switch is ON
 * (closed), regardless of the active-low wiring - gpio_pin_get_dt handles
 * the polarity inversion transparently.
 */
typedef void (*dip_change_cb_t)(uint8_t state);

uint8_t dip_switch_read(void);
void    dip_switch_set_callback(dip_change_cb_t cb);
