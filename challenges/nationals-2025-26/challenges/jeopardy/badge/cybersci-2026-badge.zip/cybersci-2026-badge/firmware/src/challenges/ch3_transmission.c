#include "challenges/ch3_transmission.h"

#include <zephyr/kernel.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/shell/shell.h>
#include <zephyr/logging/log.h>
#include <string.h>

#include "badge/badge_id.h"

LOG_MODULE_REGISTER(ch3_tx, LOG_LEVEL_INF);

/*
 * Ch3 "Numbers Station".
 *
 * Once the transmitter is on the air it loops a numbers-station broadcast in
 * its BLE advertising manufacturer data, framed [company LE][seq][total][5
 * digits] and cycling ~1 s. The advertised device name is the station callsign
 * so a player can pick their own station out of the crowd.
 *
 * Each frame carries one 5-digit ciphertext group; seq 0..total-1 cover the
 * whole message. Capture a full cycle, order by seq, concatenate the digit
 * groups -> the ciphertext digit string.
 *
 * Crypto (per-badge, all derived from the badge UID) - modelled on the Cuban
 * "Atencion" station / Cuban Five case:
 *   - plaintext flag char -> its 3-digit decimal ASCII code (e.g. 'C' -> 067)
 *   - enciphered by mod-10, no-carry ADDITION with a repeating one-time-pad key:
 *         cipher_digit = (plain_digit + key_digit) mod 10
 *   - the key ("key group") and callsign are shown on the badge's channel card
 *     after tuning and in `status`.
 *
 * Player decode (exactly as the FBI decrypted the Atencion messages):
 *     plain_digit = (cipher_digit - key_digit) mod 10   (no borrow)
 *     then read the recovered digits in 3s as ASCII codes -> flag.
 *
 * Because the key is per-badge, every badge transmits a different ciphertext
 * that only its own key group decodes (a raw capture can't be shared).
 */
static const char ch3_flag[] = "CyberSci{N0W_BR04DC4ST1NG_0N_4LL_CH4NN3LS}";

#define CH3_FREQ          "4625.0 kHz"   /* UVB-76 "The Buzzer" nod */
#define PAD_LEN           8              /* repeating key length (digits) */
#define DIGITS_PER_FRAME  5              /* one classic numbers-station group of 5 */
#define COMPANY_ID        0x1337         /* leet beacon id */

#define MAX_FLAG    50
#define MAX_DIGITS  (MAX_FLAG * 3)

static char    s_callsign[5];               /* 4 base36 chars + NUL */
static char    s_keygroup[2 * PAD_LEN];     /* "8 3 1 5 9 2 4 7" */
static uint8_t s_pad[PAD_LEN];
static char    s_cipher[MAX_DIGITS + 1];    /* ciphertext digit chars */
static size_t  s_cipher_len;
static uint8_t s_nframes;                   /* ceil(cipher_len / 5) */
static bool    s_init;

static void ch3_init_once(void)
{
	if (s_init) {
		return;
	}

	uint64_t uid = badge_id_get_uid();

	/* Per-badge repeating key digits, mixed from the UID. */
	uint64_t x = uid ^ 0x9e3779b97f4a7c15ULL;
	for (int i = 0; i < PAD_LEN; i++) {
		x = x * 6364136223846793005ULL + 1442695040888963407ULL;
		s_pad[i] = (uint8_t)((x >> 59) % 10);
		s_keygroup[2 * i]     = (char)('0' + s_pad[i]);
		s_keygroup[2 * i + 1] = ' ';
	}
	s_keygroup[2 * PAD_LEN - 1] = '\0';   /* trim trailing space */

	/* Per-badge callsign: 4 base36 chars from a different UID mix. */
	static const char b36[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	uint64_t y = uid ^ 0xd1b54a32d192ed03ULL;
	for (int i = 0; i < 4; i++) {
		y = y * 6364136223846793005ULL + 1ULL;
		s_callsign[i] = b36[(y >> 58) % 36];
	}
	s_callsign[4] = '\0';

	/* Encipher: flag char -> 3-digit ASCII -> plus key (mod 10, no carry),
	 * Atencion-style. */
	size_t flen = strlen(ch3_flag);
	size_t out = 0;
	int p = 0;
	for (size_t i = 0; i < flen && out + 3 <= MAX_DIGITS; i++) {
		uint8_t c = (uint8_t)ch3_flag[i];
		uint8_t d[3] = { (uint8_t)(c / 100 % 10),
				 (uint8_t)(c / 10 % 10),
				 (uint8_t)(c % 10) };
		for (int j = 0; j < 3; j++) {
			uint8_t k = s_pad[p++ % PAD_LEN];
			s_cipher[out++] = (char)('0' + (d[j] + k) % 10);
		}
	}
	s_cipher[out] = '\0';
	s_cipher_len = out;
	s_nframes = (uint8_t)((out + DIGITS_PER_FRAME - 1) / DIGITS_PER_FRAME);

	s_init = true;
}

void ch3_channel_card(const struct shell *sh)
{
	ch3_init_once();

	if (sh) {
		shell_print(sh, "  Callsign  : %s", s_callsign);
		shell_print(sh, "  Frequency : %s", CH3_FREQ);
		shell_print(sh, "  Key group : %s", s_keygroup);
		shell_print(sh, "  Encoding  : CP437");
	} else {
		printk("  Callsign  : %s\r\n", s_callsign);
		printk("  Frequency : %s\r\n", CH3_FREQ);
		printk("  Key group : %s\r\n", s_keygroup);
		printk("  Encoding  : CP437\r\n");
	}
}

/* ─── advertising ─────────────────────────────────────────────────────────── */

/* manufacturer data: [company LE][seq][total][digit chars] */
static uint8_t mfg[2 + 2 + DIGITS_PER_FRAME];
static uint8_t cur_seq;
static bool    running;

static struct bt_data ad[] = {
	BT_DATA_BYTES(BT_DATA_FLAGS, BT_LE_AD_NO_BREDR),
	BT_DATA(BT_DATA_NAME_COMPLETE, s_callsign, 0),   /* len set in start */
	BT_DATA(BT_DATA_MANUFACTURER_DATA, mfg, sizeof(mfg)),
};

static struct k_work_delayable rotate_work;

static void build_frame(uint8_t seq)
{
	mfg[0] = COMPANY_ID & 0xFF;
	mfg[1] = (COMPANY_ID >> 8) & 0xFF;
	mfg[2] = seq;
	mfg[3] = s_nframes;

	size_t off = (size_t)seq * DIGITS_PER_FRAME;
	size_t n = (s_cipher_len > off) ? (s_cipher_len - off) : 0;
	if (n > DIGITS_PER_FRAME) {
		n = DIGITS_PER_FRAME;
	}
	memcpy(mfg + 4, s_cipher + off, n);

	ad[2].data_len = (uint8_t)(4 + n);   /* last frame may be shorter */
}

static void rotate_fn(struct k_work *w)
{
	ARG_UNUSED(w);
	cur_seq = (uint8_t)((cur_seq + 1) % s_nframes);
	build_frame(cur_seq);
	bt_le_adv_update_data(ad, ARRAY_SIZE(ad), NULL, 0);
	k_work_reschedule(&rotate_work, K_MSEC(1000));
}

void ch3_transmission_start(void)
{
	if (running) {
		return;
	}
	ch3_init_once();

	int err = bt_enable(NULL);
	if (err && err != -EALREADY) {
		LOG_ERR("bt_enable failed (%d)", err);
		return;
	}

	ad[1].data     = (const uint8_t *)s_callsign;
	ad[1].data_len = (uint8_t)strlen(s_callsign);

	cur_seq = 0;
	build_frame(0);
	k_work_init_delayable(&rotate_work, rotate_fn);

	err = bt_le_adv_start(BT_LE_ADV_NCONN, ad, ARRAY_SIZE(ad), NULL, 0);
	if (err) {
		LOG_ERR("adv start failed (%d)", err);
		return;
	}

	running = true;
	k_work_reschedule(&rotate_work, K_MSEC(1000));
	LOG_INF("CyberSci numbers station '%s' online -- CP437 encoded", s_callsign);
}
