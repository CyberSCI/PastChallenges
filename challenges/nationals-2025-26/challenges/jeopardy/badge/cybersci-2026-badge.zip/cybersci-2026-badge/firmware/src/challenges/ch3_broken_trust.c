#include "ch3_broken_trust.h"

#include <zephyr/kernel.h>
#include <zephyr/shell/shell.h>

/*
 * Step 8 placeholder.  Real implementation (mbedTLS software ECDSA driven by
 * the broken LCG nonce generator) lands with the mbedTLS config in Step 8.
 * Stubs keep sign/verify/rng shell commands wired and the build green.
 */

int ch3_sign(const struct shell *sh, const char *message)
{
	ARG_UNUSED(message);
	shell_print(sh, "Ch3 not yet implemented.");
	return -1;
}

int ch3_verify(const struct shell *sh, const char *message,
	       const char *r_hex, const char *s_hex)
{
	ARG_UNUSED(message);
	ARG_UNUSED(r_hex);
	ARG_UNUSED(s_hex);
	shell_print(sh, "Ch3 not yet implemented.");
	return -1;
}

void ch3_rng_sample(const struct shell *sh)
{
	shell_print(sh, "Ch3 not yet implemented.");
}
