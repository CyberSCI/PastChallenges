#pragma once

/*
 * Light the hardwired "2026" on the four 7-segment digits by enabling all
 * four digit drivers (SEG_1..SEG_4 on P1.11-P1.14). Auto-runs at boot via
 * SYS_INIT; the explicit call is exposed to re-assert after a GPIO reconfig.
 *
 * Shared by both the player and mainframe firmwares — keep in sync.
 */
void segment_show_2026(void);
