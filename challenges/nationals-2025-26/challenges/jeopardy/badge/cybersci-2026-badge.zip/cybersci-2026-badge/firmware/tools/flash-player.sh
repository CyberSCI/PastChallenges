#!/bin/bash
# Production flash for ONE player badge: mass-erase + LOCK.
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo ">> PLAYER badge  (erase + LOCK)"
"$SCRIPT_DIR/badge-flash.sh" "$HOME/badgebuild/zephyr/zephyr.hex" --erase --lock
