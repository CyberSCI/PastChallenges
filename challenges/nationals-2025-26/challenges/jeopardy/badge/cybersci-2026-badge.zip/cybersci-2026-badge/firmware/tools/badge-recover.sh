#!/bin/bash
# Recover a locked (APPROTECT-enabled) nRF52840 using OpenOCD's built-in
# nrf52_recover, which runs CTRL-AP ERASEALL. This WIPES THE ENTIRE CHIP
# (firmware + UICR + NVS) and clears the APPROTECT lock so the badge can be
# flashed again afterwards.
#
# Validated on this FTDI+OpenOCD (0.12) rig: lock -> recover -> reflash works.
# After this completes, power-cycle and reflash with:  badge-flash.sh <hex> --erase
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CFG="$SCRIPT_DIR/nrf52_ftdi_swd.cfg"

# init still examines (and fails) on a locked part, but it doesn't abort the
# script, and nrf52_recover does the CTRL-AP erase regardless.
timeout 90 openocd -f "$CFG" -c "init" -c "nrf52_recover" -c "exit"
echo
echo "If you saw 'successfully erased and unlocked', reflash with:"
echo "  tools/badge-flash.sh <hex> --erase"
