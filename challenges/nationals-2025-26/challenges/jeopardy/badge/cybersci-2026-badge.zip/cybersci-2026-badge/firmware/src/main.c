#include <zephyr/kernel.h>
#include <zephyr/usb/usb_device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/logging/log.h>

#include "badge/badge_id.h"
#include "badge/state.h"
#include "hw/led.h"
#include "shell/terminal.h"
#include "challenges/ch1_last_contact.h"
#include "challenges/ch2_dead_transmission.h"
#include "challenges/ch3_transmission.h"

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

int main(void)
{
	const struct device *shell_dev =
		DEVICE_DT_GET(DT_CHOSEN(zephyr_shell_uart));

	if (!device_is_ready(shell_dev)) {
		LOG_ERR("CDC-ACM device not ready");
		return -ENODEV;
	}

	usb_enable(NULL);

	LOG_INF("Badge online - type=%u  ch1=%d ch2=%d ch3=%d",
		badge_id_get_type(),
		state_ch1_is_solved(),
		state_ch2_is_solved(),
		state_ch3_is_solved());

	/* Start the LED Morse beacon + DIP monitor immediately (independent of any
	 * USB host) - the player should see Morse on power-up. If Ch1 was already
	 * solved in a previous session, resume the post-unlock transceiver display
	 * instead (breathing red + however many fragments were already keyed in). */
	if (!state_ch1_is_solved()) {
		ch1_start();
	} else if (state_ch2_is_solved()) {
		led_twinkle();   /* on the air: same twinkle as the mainframes */
	} else {
		led_progress(ch2_progress_pixels());
	}

	/* If Ch2 was already solved in a previous session, resume the broadcast. */
	if (state_ch2_is_solved()) {
		ch3_transmission_start();
	}

	/* Wait for the USB host to open the console, THEN start the scrambled
	 * pre-Ch1 display (this is terminal output, so it needs a reader). */
	uint32_t dtr = 0;
	while (!dtr) {
		uart_line_ctrl_get(shell_dev, UART_LINE_CTRL_DTR, &dtr);
		k_sleep(K_MSEC(100));
	}

	if (!state_ch1_is_solved()) {
		terminal_start_scramble();
	}

	return 0;
}
