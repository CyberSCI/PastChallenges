#include "ch1_last_contact.h"

#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>

#include "hw/led.h"
#include "hw/dip_switch.h"
#include "shell/terminal.h"
#include "badge/state.h"
#include "challenges/ch2_dead_transmission.h"

LOG_MODULE_REGISTER(ch1, LOG_LEVEL_DBG);

/*
 * Ch1 - "Last Contact"
 *
 * The badge blinks the lost channel number in Morse on the LED strip and
 * swallows all terminal input (handled by terminal.c). The player decodes the
 * Morse digits, converts to 8-bit binary, and sets the DIP switches to match.
 *
 *   channel 26  →  decimal 26  →  binary 0001 1010  →  set switches to match
 *
 * "26" ties to the event year (badge shows "2026"). The player decodes the
 * Morse digits, writes the 8-bit binary, and flips the DIP switches to spell
 * it left-to-right (leftmost switch = P1.08 = MSB; switch in the "1" position
 * = logical 1, see board overlay). On the correct switch state the terminal
 * clears, prints the flag, the LED goes solid, and the shell unlocks.
 */
#define CH1_CHANNEL  26u                  /* 0b0001_1010 = 0x1A */

/* Thematic amber/orange - a dim emergency-beacon colour. */
#define CH1_R  255u
#define CH1_G   80u
#define CH1_B    0u

/* Same flag on every badge (Ch1 is a solo, per-badge challenge). */
#define CH1_FLAG  "CyberSci{L4ST_C0NTACT_DE_SK}"

static bool ch1_solved;   /* guards against repeated DIP callbacks post-unlock */

static void dip_changed(uint8_t state)
{
	/*
	 * Runs from the DIP debounce workqueue (thread context), so calling
	 * printk()/shell helpers from terminal_unlock() is safe here.
	 */
	if (ch1_solved) {
		return;
	}

	LOG_DBG("DIP=0x%02x target=0x%02x", state, CH1_CHANNEL);

	if (state != (uint8_t)CH1_CHANNEL) {
		return;
	}

	ch1_solved = true;

	/* Stop listening - the channel is locked for good. */
	dip_switch_set_callback(NULL);

	terminal_unlock(CH1_FLAG);
	/* Transceiver powered up: slow red breathe, filling green as keys arrive. */
	led_progress(ch2_progress_pixels());
	state_ch1_set_solved();

	LOG_INF("Ch1 solved - channel %u locked", CH1_CHANNEL);
}

const char *ch1_flag(void)
{
	return CH1_FLAG;
}

void ch1_start(void)
{
	/* Begin the looping Morse beacon and arm the DIP-switch monitor. */
	led_morse_loop(CH1_CHANNEL, CH1_R, CH1_G, CH1_B);
	dip_switch_set_callback(dip_changed);

	/*
	 * Handle the case where the player already has the correct switches set
	 * at boot: no edge will fire the callback, so evaluate the current
	 * state once up front.
	 */
	if (dip_switch_read() == (uint8_t)CH1_CHANNEL) {
		dip_changed(dip_switch_read());
	}
}
