#include "state.h"

#include <zephyr/kernel.h>
#include <zephyr/fs/nvs.h>
#include <zephyr/storage/flash_map.h>
#include <zephyr/logging/log.h>
#include <string.h>

LOG_MODULE_REGISTER(badge_state, LOG_LEVEL_INF);

/* NVS key IDs - never change these; altering them corrupts persisted state */
#define NVS_ID_FLAGS      1
#define NVS_ID_FRAG_MASK  2
#define NVS_ID_FRAG(n)   (10 + (n))   /* keys 10–19 */

/*
 * Uses the default storage_partition defined in the nRF52840dk board DTS
 * (0xf8000, 32 KB). Four 4 KB sectors = 16 KB consumed.
 * If using a custom board, ensure storage_partition is defined in its DTS.
 */
static struct nvs_fs nvs_storage = {
	.flash_device = FIXED_PARTITION_DEVICE(storage_partition),
	.offset       = FIXED_PARTITION_OFFSET(storage_partition),
	.sector_size  = 4096,
	.sector_count = 4,
};

static K_MUTEX_DEFINE(state_mutex);

static uint16_t state_flags;
static uint16_t frag_mask;
static uint8_t  fragments[FRAGMENT_COUNT][FRAGMENT_LEN];

static int state_sys_init(void)
{
	int rc = nvs_mount(&nvs_storage);
	if (rc < 0) {
		LOG_ERR("NVS mount failed: %d", rc);
		return rc;
	}

	/* nvs_read returns -ENOENT on first boot - treat as zero (default) */
	nvs_read(&nvs_storage, NVS_ID_FLAGS,     &state_flags, sizeof(state_flags));
	nvs_read(&nvs_storage, NVS_ID_FRAG_MASK, &frag_mask,   sizeof(frag_mask));

	for (int i = 0; i < FRAGMENT_COUNT; i++) {
		if (frag_mask & BIT(i)) {
			nvs_read(&nvs_storage, NVS_ID_FRAG(i),
				 fragments[i], FRAGMENT_LEN);
		}
	}

	LOG_INF("State loaded: flags=0x%04x  frags=0x%04x", state_flags, frag_mask);
	return 0;
}

SYS_INIT(state_sys_init, APPLICATION, 11);

/* ─── Internal helpers ────────────────────────────────────────────────────── */

static void persist_flags(void)
{
	nvs_write(&nvs_storage, NVS_ID_FLAGS, &state_flags, sizeof(state_flags));
}

/* ─── Challenge completion ────────────────────────────────────────────────── */

bool state_ch1_is_solved(void) { return !!(state_flags & STATE_CH1_SOLVED); }
bool state_ch2_is_solved(void) { return !!(state_flags & STATE_CH2_SOLVED); }
bool state_ch3_is_solved(void) { return !!(state_flags & STATE_CH3_SOLVED); }

void state_ch1_set_solved(void)
{
	k_mutex_lock(&state_mutex, K_FOREVER);
	state_flags |= STATE_CH1_SOLVED;
	persist_flags();
	k_mutex_unlock(&state_mutex);
}

void state_ch2_set_solved(void)
{
	k_mutex_lock(&state_mutex, K_FOREVER);
	state_flags |= STATE_CH2_SOLVED;
	persist_flags();
	k_mutex_unlock(&state_mutex);
}

void state_ch3_set_solved(void)
{
	k_mutex_lock(&state_mutex, K_FOREVER);
	state_flags |= STATE_CH3_SOLVED;
	persist_flags();
	k_mutex_unlock(&state_mutex);
}

void state_reset(void)
{
	k_mutex_lock(&state_mutex, K_FOREVER);
	state_flags = 0;
	frag_mask   = 0;
	memset(fragments, 0, sizeof(fragments));
	nvs_clear(&nvs_storage);
	k_mutex_unlock(&state_mutex);
}

/* ─── Ch2 fragment management ────────────────────────────────────────────── */

bool state_has_fragment(uint8_t type)
{
	return type < FRAGMENT_COUNT && !!(frag_mask & BIT(type));
}

uint16_t state_fragment_mask(void)
{
	return frag_mask;
}

uint8_t state_fragment_count(void)
{
	return (uint8_t)__builtin_popcount(frag_mask & ((1U << FRAGMENT_COUNT) - 1));
}

bool state_all_fragments_received(void)
{
	/* All 10 low bits set */
	return (frag_mask & ((1U << FRAGMENT_COUNT) - 1)) ==
	       ((1U << FRAGMENT_COUNT) - 1);
}

void state_store_fragment(uint8_t type, const uint8_t *data)
{
	if (type >= FRAGMENT_COUNT) {
		return;
	}

	k_mutex_lock(&state_mutex, K_FOREVER);

	memcpy(fragments[type], data, FRAGMENT_LEN);
	frag_mask |= BIT(type);

	nvs_write(&nvs_storage, NVS_ID_FRAG(type),    fragments[type], FRAGMENT_LEN);
	nvs_write(&nvs_storage, NVS_ID_FRAG_MASK,      &frag_mask,      sizeof(frag_mask));

	k_mutex_unlock(&state_mutex);
}

const uint8_t *state_get_fragment(uint8_t type)
{
	if (type >= FRAGMENT_COUNT || !(frag_mask & BIT(type))) {
		return NULL;
	}
	return fragments[type];
}
