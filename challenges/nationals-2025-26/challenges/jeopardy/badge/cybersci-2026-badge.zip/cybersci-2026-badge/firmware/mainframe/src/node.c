#include "node.h"

#include <zephyr/kernel.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/att.h>
#include <zephyr/fs/nvs.h>
#include <zephyr/storage/flash_map.h>
#include <zephyr/logging/log.h>
#include <string.h>
#include <ctype.h>

#include "hw/led.h"
#include "gen/ch2_mainframe_data.h"   /* ch2_node_name/pass[], ch2_fragment[][] */

LOG_MODULE_REGISTER(node, LOG_LEVEL_INF);

/* ─── persistence ─────────────────────────────────────────────────────────── */

#define NVS_ID_NODE_IDX 1

static struct nvs_fs nvs = {
	.flash_device = FIXED_PARTITION_DEVICE(storage_partition),
	.offset       = FIXED_PARTITION_OFFSET(storage_partition),
	.sector_size  = 4096,
	.sector_count = 4,
};

static uint8_t          node_index;
static struct bt_conn  *authed_conn;   /* connection that wrote the right password */

/* ─── GATT UUIDs (custom 128-bit; "SRV" 0x535256 ... 0x4e4f4445 'NODE') ─────── */

#define NODE_UUID(last) \
	BT_UUID_INIT_128(BT_UUID_128_ENCODE(0x53525600, 0xc1be, 0x2026, \
					    0x4e4f, 0x44450000##last))

static struct bt_uuid_128 svc_uuid      = NODE_UUID(0001);
static struct bt_uuid_128 nodetype_uuid = NODE_UUID(0002);
static struct bt_uuid_128 auth_uuid     = NODE_UUID(0003);
static struct bt_uuid_128 frag_uuid     = NODE_UUID(0004);

/* ─── characteristic handlers ─────────────────────────────────────────────── */

static ssize_t read_nodetype(struct bt_conn *conn, const struct bt_gatt_attr *attr,
			     void *buf, uint16_t len, uint16_t offset)
{
	const char *name = ch2_node_name[node_index];
	return bt_gatt_attr_read(conn, attr, buf, len, offset, name, strlen(name));
}

static ssize_t write_auth(struct bt_conn *conn, const struct bt_gatt_attr *attr,
			  const void *buf, uint16_t len, uint16_t offset,
			  uint8_t flags)
{
	ARG_UNUSED(attr);
	ARG_UNUSED(flags);

	if (offset != 0) {
		return BT_GATT_ERR(BT_ATT_ERR_INVALID_OFFSET);
	}

	/* normalize the written password: lowercase, alphanumeric only */
	char norm[48];
	size_t j = 0;
	const uint8_t *in = buf;
	for (uint16_t i = 0; i < len && j < sizeof(norm) - 1; i++) {
		if (isalnum(in[i])) {
			norm[j++] = (char)tolower(in[i]);
		}
	}
	norm[j] = '\0';

	if (strcmp(norm, ch2_node_pass[node_index]) == 0) {
		authed_conn = conn;
		LOG_INF("AUTH accepted for %s", ch2_node_name[node_index]);
	} else {
		if (conn == authed_conn) {
			authed_conn = NULL;
		}
		LOG_INF("AUTH rejected");
	}
	return len;
}

static ssize_t read_fragment(struct bt_conn *conn, const struct bt_gatt_attr *attr,
			     void *buf, uint16_t len, uint16_t offset)
{
	if (conn != authed_conn) {
		return BT_GATT_ERR(BT_ATT_ERR_AUTHENTICATION);
	}
	return bt_gatt_attr_read(conn, attr, buf, len, offset,
				 ch2_fragment[node_index], CH2_FRAG_LEN);
}

BT_GATT_SERVICE_DEFINE(node_svc,
	BT_GATT_PRIMARY_SERVICE(&svc_uuid),
	/* Characteristic User Description (0x2901) labels so a scanner shows
	 * human-readable names. They reveal WHERE to act (the mechanic), not the
	 * passwords (the puzzle). */
	BT_GATT_CHARACTERISTIC(&nodetype_uuid.uuid, BT_GATT_CHRC_READ,
			       BT_GATT_PERM_READ, read_nodetype, NULL, NULL),
	BT_GATT_CUD("SYSTEM", BT_GATT_PERM_READ),
	BT_GATT_CHARACTERISTIC(&auth_uuid.uuid, BT_GATT_CHRC_WRITE,
			       BT_GATT_PERM_WRITE, NULL, write_auth, NULL),
	BT_GATT_CUD("LOGIN", BT_GATT_PERM_READ),
	BT_GATT_CHARACTERISTIC(&frag_uuid.uuid, BT_GATT_CHRC_READ,
			       BT_GATT_PERM_READ, read_fragment, NULL, NULL),
	BT_GATT_CUD("KEYFRAG", BT_GATT_PERM_READ),
);

/* ─── advertising ─────────────────────────────────────────────────────────── */

static uint8_t       adv_flags = BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR;
static struct bt_data ad[2];

static void start_adv(void)
{
	const char *name = ch2_node_name[node_index];

	bt_set_name(name);

	ad[0].type = BT_DATA_FLAGS;
	ad[0].data = &adv_flags;
	ad[0].data_len = sizeof(adv_flags);
	ad[1].type = BT_DATA_NAME_COMPLETE;
	ad[1].data = (const uint8_t *)name;
	ad[1].data_len = strlen(name);

	int err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad), NULL, 0);
	if (err) {
		LOG_ERR("adv start failed (%d)", err);
	}
}

/* ─── connection callbacks ────────────────────────────────────────────────── */

static void connected(struct bt_conn *conn, uint8_t err)
{
	ARG_UNUSED(conn);
	LOG_INF("central connected (%u)", err);
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	LOG_INF("central disconnected (0x%02x)", reason);
	if (conn == authed_conn) {
		authed_conn = NULL;
	}
	start_adv();   /* connectable adv stops on connect; resume it */
}

BT_CONN_CB_DEFINE(conn_cbs) = {
	.connected = connected,
	.disconnected = disconnected,
};

/* ─── public API ──────────────────────────────────────────────────────────── */

uint8_t node_get_index(void)
{
	return node_index;
}

int node_set_index(uint8_t idx)
{
	if (idx >= CH2_NODE_COUNT) {
		return -1;
	}
	node_index = idx;
	nvs_write(&nvs, NVS_ID_NODE_IDX, &node_index, sizeof(node_index));

	bt_le_adv_stop();
	authed_conn = NULL;
	start_adv();
	LOG_INF("re-provisioned as %s", ch2_node_name[idx]);
	return 0;
}

/*
 * Flash-time provisioning: the low byte of UICR.CUSTOMER[0] (0x10001080) holds
 * the node index when written at flash time (badge-flash.sh --node N). Erased
 * UICR reads 0xFF -> not provisioned. UICR takes precedence over the NVS value
 * set by the runtime `node` command, so production badges need no console step.
 */
#define UICR_CUSTOMER0  (*(volatile uint32_t *)0x10001080UL)

void node_start(void)
{
	if (nvs_mount(&nvs) < 0) {
		LOG_ERR("NVS mount failed");
	} else if (nvs_read(&nvs, NVS_ID_NODE_IDX, &node_index,
			    sizeof(node_index)) <= 0) {
		node_index = 0;   /* unprovisioned -> default to node 0 */
	}

	uint8_t uicr_idx = (uint8_t)(UICR_CUSTOMER0 & 0xFFu);
	if (uicr_idx < CH2_NODE_COUNT) {
		node_index = uicr_idx;   /* flash-time provisioning wins */
	}

	if (node_index >= CH2_NODE_COUNT) {
		node_index = 0;
	}

	led_twinkle();   /* multicolour sparkles with a periodic dark gap */

	int err = bt_enable(NULL);
	if (err) {
		LOG_ERR("bt_enable failed (%d)", err);
		return;
	}

	start_adv();
	LOG_INF("Mainframe online: node %u = '%s'",
		node_index, ch2_node_name[node_index]);
}
