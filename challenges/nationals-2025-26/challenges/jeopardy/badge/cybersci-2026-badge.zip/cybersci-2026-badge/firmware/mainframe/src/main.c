#include <zephyr/kernel.h>
#include <zephyr/usb/usb_device.h>
#include <zephyr/shell/shell.h>
#include <zephyr/logging/log.h>
#include <stdlib.h>

#include "node.h"
#include "gen/ch2_mainframe_data.h"

LOG_MODULE_REGISTER(mainframe, LOG_LEVEL_INF);

/* ─── provisioning command: `node [0-9]` ─────────────────────────────────── */

static int cmd_node(const struct shell *sh, size_t argc, char **argv)
{
	if (argc == 1) {
		uint8_t i = node_get_index();
		shell_print(sh, "node %u = %s", i, ch2_node_name[i]);
		shell_print(sh, "set with: node <0-%d>", CH2_NODE_COUNT - 1);
		return 0;
	}

	int i = atoi(argv[1]);
	if (i < 0 || i >= CH2_NODE_COUNT || node_set_index((uint8_t)i) < 0) {
		shell_print(sh, "Invalid — node <0-%d>", CH2_NODE_COUNT - 1);
		return -EINVAL;
	}

	shell_print(sh, "Provisioned as %s — now advertising.", ch2_node_name[i]);
	return 0;
}

SHELL_CMD_ARG_REGISTER(node, NULL, "Provision mainframe identity (0-9)",
		       cmd_node, 1, 1);

int main(void)
{
	const struct device *shell_dev =
		DEVICE_DT_GET(DT_CHOSEN(zephyr_shell_uart));

	if (device_is_ready(shell_dev)) {
		usb_enable(NULL);   /* CDC-ACM console for provisioning */
	}

	node_start();
	return 0;
}
