#!/bin/bash
# Flash a hex over FTDI SWD.
#   badge-flash.sh [hexfile] [--erase] [--node N] [--lock]
#     --erase   full mass-erase before programming (fresh NVS/state)
#     --node N  provision mainframe node index N (0-9) into UICR.CUSTOMER[0]
#               (flash-time provisioning; no console `node` step needed)
#     --lock    enable APPROTECT readback protection (UICR), then reset.
#               The chip then CANNOT be read or reflashed over SWD until you run
#               badge-recover.sh (CTRL-AP ERASEALL, which wipes the whole chip).
#
# --node and --lock are applied together in one UICR session (after program).
# Separate OpenOCD sessions per step — combining mass_erase + program in one
# session is flaky on these parts (NVMC errors).
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CFG="$SCRIPT_DIR/nrf52_ftdi_swd.cfg"
HEX="${1:-$HOME/badgebuild/zephyr/zephyr.hex}"
ERASE=0; LOCK=0; NODE=""
args=("$@"); i=0
while [ $i -lt ${#args[@]} ]; do
  case "${args[$i]}" in
    --erase) ERASE=1 ;;
    --lock)  LOCK=1 ;;
    --node)  i=$((i+1)); NODE="${args[$i]}" ;;
  esac
  i=$((i+1))
done

if [ -n "$NODE" ] && ! { [ "$NODE" -ge 0 ] 2>/dev/null && [ "$NODE" -le 9 ]; }; then
  echo "error: --node must be 0-9" >&2; exit 2
fi

run() { timeout 150 openocd -f "$CFG" "$@"; }

if [ "$ERASE" = 1 ]; then
  echo "== mass erase =="
  run -c "init" -c "reset halt" -c "nrf5 mass_erase" -c "exit" || exit 1
fi

echo "== program $HEX =="
if [ "$ERASE" = 1 ]; then
  # Chip is blank after mass_erase, so write WITHOUT a per-page erase: avoids the
  # flaky NVMC ERASEPAGE (reg 0x4001e508) that intermittently fails over the
  # bare-FTDI SWD link ("Failed to erase reg / Error erasing sector N").
  run -c "init" -c "reset halt" -c "flash write_image $HEX" -c "verify_image $HEX" \
      -c "reset run" -c "exit" || exit 1
else
  # No mass-erase: must erase the written pages, so use program (may hit the
  # ERASEPAGE flakiness — re-run if it fails, or add --erase).
  run -c "init" -c "reset halt" -c "program $HEX verify" -c "reset run" -c "exit" || exit 1
fi

# UICR session: provision node index and/or set APPROTECT. UICR words are
# written via NVMC (WEN) from a clean reset-halt; the flash write algorithm
# (flash fillw) times out for single words.
if [ -n "$NODE" ] || [ "$LOCK" = 1 ]; then
  echo "== UICR (provision/lock) =="
  CMDS=(-c "init" -c "reset halt" -c "mww 0x4001e504 0x00000001")   # NVMC WEN
  if [ -n "$NODE" ]; then
    NVAL=$(printf '0xffffff%02x' "$NODE")                          # CUSTOMER[0] low byte = N
    CMDS+=(-c "mww 0x10001080 $NVAL" -c "sleep 50")
  fi
  if [ "$LOCK" = 1 ]; then
    CMDS+=(-c "mww 0x10001208 0xffffff00" -c "sleep 50")           # APPROTECT PALL = Enabled
  fi
  CMDS+=(-c "mww 0x4001e504 0x00000000")                           # NVMC REN
  [ -n "$NODE" ] && CMDS+=(-c "mdw 0x10001080")
  [ "$LOCK" = 1 ] && CMDS+=(-c "mdw 0x10001208")
  CMDS+=(-c "reset run" -c "exit")
  run "${CMDS[@]}" || exit 1
  [ -n "$NODE" ] && echo "provisioned node index $NODE (UICR.CUSTOMER[0])"
  [ "$LOCK" = 1 ] && echo "!! LOCKED: this badge now rejects SWD readback/flash. Recover with badge-recover.sh."
fi
