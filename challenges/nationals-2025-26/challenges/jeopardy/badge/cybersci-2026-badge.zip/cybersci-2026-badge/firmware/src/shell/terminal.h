#pragma once

#include <zephyr/shell/shell.h>

/*
 * Start the scrolling noise display. Called from main() immediately after
 * the USB host asserts DTR, but only when Ch1 is not yet solved.
 */
void terminal_start_scramble(void);

/*
 * Called by ch1_last_contact when the correct DIP switch state is confirmed.
 * Cancels the noise display, clears the screen, prints the flag, and hands
 * control back to the Zephyr shell.
 */
void terminal_unlock(const char *flag);

/* Switch the shell prompt to the green "transmitter online" colour. Called
 * when Ch2 is solved (the badge goes on the air). */
void terminal_prompt_online(void);

/* Shell instance - used by challenge modules that print outside a handler. */
const struct shell *terminal_get_shell(void);
