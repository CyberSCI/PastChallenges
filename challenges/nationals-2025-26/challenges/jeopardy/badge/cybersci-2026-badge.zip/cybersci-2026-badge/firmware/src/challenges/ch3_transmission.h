#pragma once

#include <zephyr/shell/shell.h>

/*
 * Ch3 - once Ch2 is solved the badge's radio comes online and begins
 * broadcasting a rotating numbers station in its BLE advertising manufacturer
 * data: frames [company-id][seq][total][cipher digits] cycling ~1s, with the
 * station callsign as the advertised device name. The flag is encoded as
 * 3-digit ASCII codes enciphered (mod-10) with a per-badge key. See the
 * channel card (post-tuning / `status`) for the callsign + key group.
 *
 * Players capture it with any BLE scanner (nRF Connect / btmon - no pairing),
 * order by seq, reassemble the digits, and decode with their key group.
 *
 * Idempotent; safe to call from a shell handler or from main() at boot when
 * Ch2 was already solved in a previous session.
 */
void ch3_transmission_start(void);

/*
 * Print this badge's "channel card" (callsign, frequency, key group). Pass a
 * shell to print there, or NULL to printk (used by the Ch1 unlock banner).
 */
void ch3_channel_card(const struct shell *sh);
