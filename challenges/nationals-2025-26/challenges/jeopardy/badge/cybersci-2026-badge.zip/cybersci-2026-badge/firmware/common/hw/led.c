#include "led.h"

#include <zephyr/kernel.h>
#include <zephyr/drivers/led_strip.h>
#include <zephyr/logging/log.h>
#include <string.h>

LOG_MODULE_REGISTER(led, LOG_LEVEL_DBG);

#define LED_COUNT      20
#define MORSE_UNIT_MS  200   /* 1 dit = 200 ms; dah = 3× = 600 ms */

/* Global LED brightness scale (0-255). Lower = dimmer = less battery draw.
 * Applied to every pixel, so it dims Morse, solid, and pulse uniformly. */
#define LED_BRIGHTNESS 32    /* ~12.5% (halved for battery life) */

/* Dark gap between Morse repeats. Kept long so that if the badge is switched
 * off between transmissions the LEDs are most likely already dark. */
#define MORSE_GAP_MS   2500

static const struct device *strip = DEVICE_DT_GET(DT_NODELABEL(led_strip));
static struct led_rgb pixels[LED_COUNT];

/* ─── Command queue ───────────────────────────────────────────────────────── */

enum led_cmd_type {
	LED_CMD_OFF,
	LED_CMD_SOLID,
	LED_CMD_MORSE_LOOP,
	LED_CMD_PULSE,
	LED_CMD_PROGRESS,   /* breathing red + green "filled" pixels (post-unlock) */
	LED_CMD_TWINKLE,    /* multicolour sparkles + periodic dark gap (mainframe) */
};

struct led_cmd {
	enum led_cmd_type type;
	uint8_t r, g, b;
	uint8_t channel;   /* MORSE_LOOP channel #, or PROGRESS green-pixel count */
};

/* Vivid palette for the mainframe twinkle (scaled dim at render time). */
static const struct { uint8_t r, g, b; } twinkle_palette[] = {
	{255, 0, 0}, {0, 255, 0}, {0, 0, 255}, {255, 160, 0},
	{0, 255, 255}, {255, 0, 255}, {255, 255, 255}, {120, 0, 255},
};

K_MSGQ_DEFINE(led_msgq, sizeof(struct led_cmd), 4, 4);
static ATOMIC_DEFINE(stop_flag, 1);

/*
 * bg_cmd: the last non-pulse command, restored automatically after a pulse
 * so a brief flash doesn't permanently disrupt a running morse loop.
 */
static struct led_cmd bg_cmd = {.type = LED_CMD_OFF};

static void send_cmd(struct led_cmd cmd)
{
	if (cmd.type != LED_CMD_PULSE) {
		bg_cmd = cmd;
	}
	atomic_set(stop_flag, 1);
	k_msgq_purge(&led_msgq);
	k_msgq_put(&led_msgq, &cmd, K_NO_WAIT);
}

/* ─── Strip helpers ───────────────────────────────────────────────────────── */

static inline uint8_t led_scale(uint8_t v)
{
	return (uint8_t)(((uint16_t)v * LED_BRIGHTNESS) / 255);
}

static void strip_fill(uint8_t r, uint8_t g, uint8_t b)
{
	for (int i = 0; i < LED_COUNT; i++) {
		pixels[i].r = led_scale(r);
		pixels[i].g = led_scale(g);
		pixels[i].b = led_scale(b);
	}
	led_strip_update_rgb(strip, pixels, LED_COUNT);
}

/*
 * Sleep for ms, checking stop_flag every 25 ms.
 * Returns true if the full duration elapsed, false if interrupted.
 */
static bool anim_sleep(int ms)
{
	while (ms > 0) {
		int chunk = (ms < 25) ? ms : 25;
		k_sleep(K_MSEC(chunk));
		ms -= chunk;
		if (atomic_get(stop_flag)) {
			return false;
		}
	}
	return true;
}

/* ─── Morse code ──────────────────────────────────────────────────────────── */

static const char *const morse_digits[10] = {
	"-----",  /* 0 */
	".----",  /* 1 */
	"..---",  /* 2 */
	"...--",  /* 3 */
	"....-",  /* 4 */
	".....",  /* 5 */
	"-....",  /* 6 */
	"--...",  /* 7 */
	"---..",  /* 8 */
	"----.",  /* 9 */
};

/*
 * Blink a single Morse digit. After the last symbol the inter-letter gap
 * (3u) is used so the caller does not need to add one between digits.
 * Returns false if interrupted.
 */
static bool morse_blink_digit(uint8_t digit, uint8_t r, uint8_t g, uint8_t b)
{
	const char *seq = morse_digits[digit % 10];

	for (int i = 0; seq[i]; i++) {
		int on_ms  = (seq[i] == '.') ? MORSE_UNIT_MS : (3 * MORSE_UNIT_MS);
		int off_ms = seq[i + 1] ? MORSE_UNIT_MS : (3 * MORSE_UNIT_MS);

		strip_fill(r, g, b);
		if (!anim_sleep(on_ms))  return false;
		strip_fill(0, 0, 0);
		if (!anim_sleep(off_ms)) return false;
	}
	return true;
}

/*
 * Blink channel (0–255) as decimal Morse (no leading zeros; 0 blinks "0").
 * Returns false if interrupted.
 */
static bool morse_blink_number(uint8_t channel, uint8_t r, uint8_t g, uint8_t b)
{
	uint8_t digits[3];
	int     ndigits = 0;

	if (channel >= 100) { digits[ndigits++] = channel / 100; }
	if (channel >= 10)  { digits[ndigits++] = (channel / 10) % 10; }
	digits[ndigits++] = channel % 10;

	for (int i = 0; i < ndigits; i++) {
		if (!morse_blink_digit(digits[i], r, g, b)) return false;
	}
	return true;
}

/* ─── Progress display (post-unlock) ──────────────────────────────────────── */

/*
 * Slowly breathe dim red across the strip while holding the first `green`
 * pixels solid green — a "transceiver charging" bar that fills as fragments
 * are keyed in. Loops until interrupted by another led_* command.
 */
static void progress_loop(uint8_t green)
{
	if (green > LED_COUNT) {
		green = LED_COUNT;
	}

	const int STEPS = 48;   /* half-cycle; 2*STEPS*40ms ~= 3.8 s per breath */

	while (!atomic_get(stop_flag)) {
		for (int k = 0; k < 2 * STEPS; k++) {
			int up = (k < STEPS) ? k : (2 * STEPS - k);   /* 0..STEPS */
			uint8_t rraw = (uint8_t)(12 + (138 * up) / STEPS);

			for (int i = 0; i < LED_COUNT; i++) {
				if (i < green) {
					pixels[i].r = 0;
					pixels[i].g = led_scale(150);
					pixels[i].b = 0;
				} else {
					pixels[i].r = led_scale(rraw);
					pixels[i].g = 0;
					pixels[i].b = 0;
				}
			}
			led_strip_update_rgb(strip, pixels, LED_COUNT);

			if (!anim_sleep(40)) {
				return;
			}
		}
	}
}

/* ─── Twinkle display (mainframe ambience) ─────────────────────────────────── */

/*
 * Multicolour sparkles: each frame fades all pixels toward black and ignites a
 * couple at random palette colours. Every ~11 s the strip goes fully dark for
 * ~1 s — a safe window to switch the badge off. Loops until interrupted.
 */
static void twinkle_loop(void)
{
	uint32_t s = (k_uptime_get_32() * 2654435761u) ^ 0x7ce1f00du;
	int frame = 0;

	const int CYCLE     = 220;   /* frames/cycle (~50ms each => ~11 s) */
	const int DARK_FROM = 200;   /* frames 200..219 dark (~1 s) */

	memset(pixels, 0, sizeof(pixels));

	while (!atomic_get(stop_flag)) {
		if ((frame % CYCLE) >= DARK_FROM) {
			memset(pixels, 0, sizeof(pixels));
		} else {
			for (int i = 0; i < LED_COUNT; i++) {
				pixels[i].r = (uint8_t)(pixels[i].r * 13 / 16);
				pixels[i].g = (uint8_t)(pixels[i].g * 13 / 16);
				pixels[i].b = (uint8_t)(pixels[i].b * 13 / 16);
			}

			int ignitions = 1 + (int)(s & 1u);
			for (int n = 0; n < ignitions; n++) {
				s = s * 1664525u + 1013904223u;
				int idx = (int)((s >> 8) % LED_COUNT);
				uint32_t pi = (s >> 16) % ARRAY_SIZE(twinkle_palette);
				pixels[idx].r = led_scale(twinkle_palette[pi].r);
				pixels[idx].g = led_scale(twinkle_palette[pi].g);
				pixels[idx].b = led_scale(twinkle_palette[pi].b);
			}
		}

		led_strip_update_rgb(strip, pixels, LED_COUNT);
		frame++;
		s = s * 1664525u + 1013904223u;

		if (!anim_sleep(50)) {
			return;
		}
	}
}

/* ─── LED animation thread ────────────────────────────────────────────────── */

#define LED_STACK_SIZE 1024

K_THREAD_STACK_DEFINE(led_stack, LED_STACK_SIZE);
static struct k_thread led_thread_data;

static void led_thread(void *a, void *b, void *c)
{
	ARG_UNUSED(a);
	ARG_UNUSED(b);
	ARG_UNUSED(c);

	struct led_cmd cmd;

	while (1) {
		k_msgq_get(&led_msgq, &cmd, K_FOREVER);
		atomic_set(stop_flag, 0);

		switch (cmd.type) {
		case LED_CMD_OFF:
			strip_fill(0, 0, 0);
			break;

		case LED_CMD_SOLID:
			strip_fill(cmd.r, cmd.g, cmd.b);
			break;

		case LED_CMD_MORSE_LOOP:
			while (!atomic_get(stop_flag)) {
				if (!morse_blink_number(cmd.channel, cmd.r, cmd.g, cmd.b)) {
					break;
				}
				if (!anim_sleep(MORSE_GAP_MS)) {   /* long dark gap */
					break;
				}
			}
			break;

		case LED_CMD_PULSE:
			strip_fill(cmd.r, cmd.g, cmd.b);
			k_sleep(K_MSEC(150));          /* pulse always completes */
			strip_fill(bg_cmd.r, bg_cmd.g, bg_cmd.b);
			/*
			 * Re-enqueue bg_cmd if nothing else arrived during the
			 * pulse so looping animations (e.g. morse) resume.
			 */
			if (k_msgq_num_used_get(&led_msgq) == 0) {
				k_msgq_put(&led_msgq, &bg_cmd, K_NO_WAIT);
			}
			break;

		case LED_CMD_PROGRESS:
			progress_loop(cmd.channel);
			break;

		case LED_CMD_TWINKLE:
			twinkle_loop();
			break;
		}
	}
}

/* ─── SYS_INIT ────────────────────────────────────────────────────────────── */

static int led_sys_init(void)
{
	if (!device_is_ready(strip)) {
		LOG_ERR("LED strip not ready");
		return -ENODEV;
	}

	strip_fill(0, 0, 0);

	k_thread_create(&led_thread_data, led_stack,
			K_THREAD_STACK_SIZEOF(led_stack),
			led_thread, NULL, NULL, NULL,
			K_PRIO_PREEMPT(10), 0, K_NO_WAIT);
	k_thread_name_set(&led_thread_data, "led");

	return 0;
}

SYS_INIT(led_sys_init, APPLICATION, 20);

/* ─── Public API ──────────────────────────────────────────────────────────── */

void led_off(void)
{
	send_cmd((struct led_cmd){.type = LED_CMD_OFF});
}

void led_solid(uint8_t r, uint8_t g, uint8_t b)
{
	send_cmd((struct led_cmd){.type = LED_CMD_SOLID, .r = r, .g = g, .b = b});
}

void led_morse_loop(uint8_t channel_num, uint8_t r, uint8_t g, uint8_t b)
{
	send_cmd((struct led_cmd){
		.type    = LED_CMD_MORSE_LOOP,
		.channel = channel_num,
		.r = r, .g = g, .b = b,
	});
}

void led_pulse_once(uint8_t r, uint8_t g, uint8_t b)
{
	send_cmd((struct led_cmd){.type = LED_CMD_PULSE, .r = r, .g = g, .b = b});
}

void led_progress(uint8_t green_count)
{
	send_cmd((struct led_cmd){.type = LED_CMD_PROGRESS, .channel = green_count});
}

void led_twinkle(void)
{
	send_cmd((struct led_cmd){.type = LED_CMD_TWINKLE});
}
