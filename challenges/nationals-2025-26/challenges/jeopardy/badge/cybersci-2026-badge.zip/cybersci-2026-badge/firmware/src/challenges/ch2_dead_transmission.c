#include "ch2_dead_transmission.h"
#include "challenges/ch3_transmission.h"

#include <zephyr/kernel.h>
#include <zephyr/shell/shell.h>
#include <zephyr/sys/crc.h>
#include <zephyr/logging/log.h>
#include <string.h>
#include <ctype.h>

#include "badge/state.h"
#include "hw/led.h"
#include "shell/terminal.h"
#include "gen/ch2_player_data.h"   /* ch2_node_name[], ch2_frag_crc[], CH2_* */

LOG_MODULE_REGISTER(ch2, LOG_LEVEL_INF);

BUILD_ASSERT(CH2_FRAG_LEN == FRAGMENT_LEN, "fragment length mismatch");
BUILD_ASSERT(CH2_NODE_COUNT == FRAGMENT_COUNT, "node count mismatch");

/* ─── name normalization / lookup ─────────────────────────────────────────── */

static void normalize(const char *in, char *out, size_t out_sz)
{
	size_t j = 0;
	for (size_t i = 0; in[i] && j < out_sz - 1; i++) {
		if (isalnum((unsigned char)in[i])) {
			out[j++] = (char)tolower((unsigned char)in[i]);
		}
	}
	out[j] = '\0';
}

int ch2_node_index(const char *name)
{
	char want[24];
	normalize(name, want, sizeof(want));

	for (int i = 0; i < CH2_NODE_COUNT; i++) {
		char have[24];
		normalize(ch2_node_name[i], have, sizeof(have));
		if (strcmp(want, have) == 0) {
			return i;
		}
	}
	return -1;
}

const char *ch2_node_name_of(uint8_t index)
{
	return index < CH2_NODE_COUNT ? ch2_node_name[index] : "?";
}

/* ─── hex parsing ─────────────────────────────────────────────────────────── */

static int hex_nibble(char c)
{
	if (c >= '0' && c <= '9') return c - '0';
	if (c >= 'a' && c <= 'f') return c - 'a' + 10;
	if (c >= 'A' && c <= 'F') return c - 'A' + 10;
	return -1;
}

static bool parse_hex(const char *s, uint8_t *out, size_t out_len)
{
	if (strlen(s) != out_len * 2) {
		return false;
	}
	for (size_t i = 0; i < out_len; i++) {
		int hi = hex_nibble(s[2 * i]);
		int lo = hex_nibble(s[2 * i + 1]);
		if (hi < 0 || lo < 0) {
			return false;
		}
		out[i] = (uint8_t)((hi << 4) | lo);
	}
	return true;
}

bool ch2_accept_key(uint8_t index, const char *hex_str)
{
	if (index >= CH2_NODE_COUNT) {
		return false;
	}

	uint8_t frag[CH2_FRAG_LEN];
	if (!parse_hex(hex_str, frag, sizeof(frag))) {
		return false;
	}

	if (crc32_ieee(frag, sizeof(frag)) != ch2_frag_crc[index]) {
		return false;   /* wrong fragment for this node */
	}

	state_store_fragment(index, frag);
	return true;
}

/* ─── GF(2^8) - Shamir reconstruction (AES poly 0x11b) ────────────────────── */

static uint8_t gf_mul(uint8_t a, uint8_t b)
{
	uint8_t p = 0;
	for (int i = 0; i < 8; i++) {
		if (b & 1) {
			p ^= a;
		}
		uint8_t hi = a & 0x80;
		a <<= 1;
		if (hi) {
			a ^= 0x1b;
		}
		b >>= 1;
	}
	return p;
}

static uint8_t gf_pow(uint8_t a, int e)
{
	uint8_t r = 1;
	while (e--) {
		r = gf_mul(r, a);
	}
	return r;
}

static inline uint8_t gf_inv(uint8_t a)
{
	return gf_pow(a, 254);   /* a^(255-1) in GF(2^8) */
}

/*
 * Lagrange-interpolate each of the 32 secret bytes at x=0 from the stored
 * shares. Share for node i sits at x = i+1. Uses all available shares.
 */
static void shamir_reconstruct(uint8_t out[CH2_FRAG_LEN])
{
	uint8_t idx[CH2_NODE_COUNT];
	uint8_t basis[CH2_NODE_COUNT];
	int n = 0;

	for (int i = 0; i < CH2_NODE_COUNT; i++) {
		if (state_has_fragment(i)) {
			idx[n++] = i;
		}
	}

	/* basis_j = prod_{m!=j} x_m / (x_m ^ x_j)  (subtraction == XOR in GF2) */
	for (int j = 0; j < n; j++) {
		uint8_t xj = idx[j] + 1;
		uint8_t b = 1;
		for (int m = 0; m < n; m++) {
			if (m == j) {
				continue;
			}
			uint8_t xm = idx[m] + 1;
			b = gf_mul(b, gf_mul(xm, gf_inv(xm ^ xj)));
		}
		basis[j] = b;
	}

	for (int pos = 0; pos < CH2_FRAG_LEN; pos++) {
		uint8_t acc = 0;
		for (int j = 0; j < n; j++) {
			const uint8_t *frag = state_get_fragment(idx[j]);
			acc ^= gf_mul(frag[pos], basis[j]);
		}
		out[pos] = acc;
	}
}

/* ─── decrypt ─────────────────────────────────────────────────────────────── */

bool ch2_decrypt(const struct shell *sh)
{
	uint8_t have = state_fragment_count();

	if (have < CH2_THRESHOLD) {
		shell_print(sh, "Signal too weak: %u/%u shares (need %u).",
			    have, CH2_NODE_COUNT, CH2_THRESHOLD);
		return false;
	}

	uint8_t secret[CH2_FRAG_LEN];
	shamir_reconstruct(secret);

	if (crc32_ieee(secret, sizeof(secret)) != CH2_FLAG_CRC) {
		shell_print(sh, "Reconstruction failed - a fragment is corrupt.");
		return false;
	}

	/* secret is the null-padded ASCII flag */
	char flag[CH2_FRAG_LEN + 1];
	memcpy(flag, secret, CH2_FRAG_LEN);
	flag[CH2_FRAG_LEN] = '\0';

	shell_print(sh, "");
	shell_print(sh, "  >>> TRANSMISSION DECODED <<<");
	shell_print(sh, "  %s", flag);
	shell_print(sh, "");
	shell_print(sh, "  Your radio is back ON THE AIR.");
	shell_print(sh, "");

	if (!state_ch2_is_solved()) {
		state_ch2_set_solved();
		ch3_transmission_start();    /* badge begins broadcasting (Ch3) */
		led_twinkle();               /* on the air: same twinkle as the mainframes */
		terminal_prompt_online();    /* prompt turns green */
	}
	return true;
}

uint8_t ch2_progress_pixels(void)
{
	uint8_t count = state_fragment_count();
	if (count >= CH2_THRESHOLD) {
		return CH2_STRIP_LEN;   /* threshold reached -> full green */
	}
	return (uint8_t)(((uint16_t)count * CH2_STRIP_LEN) / CH2_THRESHOLD);
}

bool ch2_get_flag(char *out, size_t out_sz)
{
	if (out_sz < CH2_FRAG_LEN + 1 || state_fragment_count() < CH2_THRESHOLD) {
		return false;
	}

	uint8_t secret[CH2_FRAG_LEN];
	shamir_reconstruct(secret);

	if (crc32_ieee(secret, sizeof(secret)) != CH2_FLAG_CRC) {
		return false;
	}

	memcpy(out, secret, CH2_FRAG_LEN);
	out[CH2_FRAG_LEN] = '\0';
	return true;
}
