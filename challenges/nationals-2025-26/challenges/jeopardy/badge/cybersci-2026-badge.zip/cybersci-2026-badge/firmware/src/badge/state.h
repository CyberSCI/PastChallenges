#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <zephyr/sys/util.h>
#include "badge_id.h"

#define FRAGMENT_LEN   32                  /* bytes per Shamir share (== flag length) */
#define FRAGMENT_COUNT BADGE_TYPE_COUNT    /* one fragment per mainframe node */

#define STATE_CH1_SOLVED  BIT(0)
#define STATE_CH2_SOLVED  BIT(1)
#define STATE_CH3_SOLVED  BIT(2)

/* ─── Challenge completion ────────────────────────────────────────────────── */
bool state_ch1_is_solved(void);
void state_ch1_set_solved(void);

bool state_ch2_is_solved(void);
void state_ch2_set_solved(void);

bool state_ch3_is_solved(void);
void state_ch3_set_solved(void);

/* Erase all persisted state (organiser reset). */
void state_reset(void);

/* ─── Ch2 fragment tracking ───────────────────────────────────────────────── */
bool           state_has_fragment(uint8_t type);
uint16_t       state_fragment_mask(void);          /* 10-bit received bitmask */
uint8_t        state_fragment_count(void);         /* number of fragments stored */
bool           state_all_fragments_received(void);
void           state_store_fragment(uint8_t type, const uint8_t *data);
const uint8_t *state_get_fragment(uint8_t type);   /* NULL if not yet received */
