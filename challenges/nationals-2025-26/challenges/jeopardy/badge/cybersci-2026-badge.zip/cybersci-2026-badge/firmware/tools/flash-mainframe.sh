#!/bin/bash
# Production flash for ONE mainframe badge: mass-erase + provision node + LOCK.
#   flash-mainframe.sh <0-9>
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
NAMES=(WOPR "THE GIBSON" "SETEC ASTRONOMY" ORACLE VAX "AS/400" IRIX MIRAI NETGEAR SAP)
N="$1"
if ! { [ "$N" -ge 0 ] 2>/dev/null && [ "$N" -le 9 ]; }; then
  echo "usage: flash-mainframe.sh <0-9>"
  echo "  0 WOPR   1 THE GIBSON   2 SETEC ASTRONOMY   3 ORACLE   4 VAX"
  echo "  5 AS/400 6 IRIX         7 MIRAI             8 NETGEAR  9 SAP"
  exit 2
fi
echo ">> MAINFRAME node $N = ${NAMES[$N]}  (erase + provision + LOCK)"
"$SCRIPT_DIR/badge-flash.sh" "$HOME/mainframebuild/zephyr/zephyr.hex" --erase --node "$N" --lock
