#pragma once
#include <stdint.h>

void led_off(void);
void led_solid(uint8_t r, uint8_t g, uint8_t b);

/*
 * Blink channel_num in Morse code (decimal digits, no leading zeros) using
 * the given colour. Loops indefinitely with a 2-second gap between repeats.
 * Automatically interrupted by any subsequent led_* call.
 */
void led_morse_loop(uint8_t channel_num, uint8_t r, uint8_t g, uint8_t b);

/*
 * Brief single flash of (r,g,b), then restores the previous steady state.
 * Safe to call from any context, including BLE callbacks.
 */
void led_pulse_once(uint8_t r, uint8_t g, uint8_t b);

/*
 * Post-unlock "transceiver charging" bar: the strip slowly breathes dim red
 * while the first `green_count` pixels are held solid green, showing how many
 * fragments have been keyed in. Loops until the next led_* call.
 */
void led_progress(uint8_t green_count);

/*
 * Mainframe ambience: multicolour twinkling sparkles with a ~1 s all-dark
 * pause every several seconds (a safe window to switch the badge off).
 */
void led_twinkle(void);
