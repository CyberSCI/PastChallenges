#include "hw/segment.h"

#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(segment, LOG_LEVEL_INF);

/*
 * 7-segment "2026" driver + boot/glitch animation.
 *
 * Each of the four digits is a low-side NPN switch on SEG_1..SEG_4 =
 * P1.11..P1.14; driving a pin high lights that digit's hardwired glyph. The
 * digits are independently wired (not a multiplexed segment bus), so we can
 * address all four at once.
 *
 * There is no brightness pin, so the boot fade-in is done with software PWM
 * (toggle the digit-enable fast with a ramping duty cycle). Once faded in we
 * switch to plain on/off GPIO for the perpetual "glitch" animation, so the
 * thread mostly sleeps rather than burning CPU.
 *
 * Shared by the player and mainframe firmwares — keep in sync.
 */
#define SEG_FIRST   11                                   /* P1.11 */
#define N_DIG       4                                    /* P1.11..P1.14 */
#define SEG_MASK    (BIT(11) | BIT(12) | BIT(13) | BIT(14))

#define PWM_LEVELS  80     /* software-PWM resolution during the fade (fine, so the
			    * ramp stays smooth even up to a low steady level) */
#define SUBSTEP_US  25     /* -> frame = 80*25us = 2000us (500 Hz, flicker-free) */
#define FADE_STEP_FRAMES 26   /* frames per brightness step; raise to slow the fade */

/* The steady "2026" is the badge's biggest continuous power draw (always lit,
 * no hardware dimming), so software-PWM it well below full brightness. Tune
 * SEG_BRIGHT_PCT to trade brightness for battery life. */
#define SEG_BRIGHT_PCT    15                                /* steady duty (%) */
#define SEG_PWM_PERIOD_US 4000                              /* ~250 Hz toggle */
#define SEG_STEADY_LEVEL  ((PWM_LEVELS * SEG_BRIGHT_PCT + 50) / 100)  /* fade target */

static const struct device *const gpio1 = DEVICE_DT_GET(DT_NODELABEL(gpio1));

static uint8_t bright[N_DIG];   /* 0..PWM_LEVELS, used only during the fade */

/* Write the digit-enable lines directly (raw == ignore active-low config). */
static inline void seg_set(uint32_t on_mask)
{
	gpio_port_set_masked_raw(gpio1, SEG_MASK, on_mask & SEG_MASK);
}

/* Software-PWM the current bright[] for `frames` PWM frames. */
static void pwm_render(int frames)
{
	for (int f = 0; f < frames; f++) {
		for (int lvl = 0; lvl < PWM_LEVELS; lvl++) {
			uint32_t on = 0;
			for (int d = 0; d < N_DIG; d++) {
				if (bright[d] > lvl) {
					on |= BIT(SEG_FIRST + d);
				}
			}
			seg_set(on);
			k_busy_wait(SUBSTEP_US);
		}
	}
}

void segment_show_2026(void)
{
	if (device_is_ready(gpio1)) {
		seg_set(SEG_MASK);   /* force all digits steady-on */
	}
}

/*
 * Show `mask` for ~`ms`, software-PWM'd to SEG_BRIGHT_PCT duty so the always-on
 * "2026" doesn't sink full segment current. k_usleep lets the core idle between
 * toggles, so this saves segment power without much CPU cost. A mask with no
 * lit segments just sleeps (display dark).
 */
static void seg_show(uint32_t mask, int ms)
{
	if ((mask & SEG_MASK) == 0u) {
		seg_set(0);
		k_msleep(ms);
		return;
	}
	const int on_us  = SEG_PWM_PERIOD_US * SEG_BRIGHT_PCT / 100;
	const int off_us = SEG_PWM_PERIOD_US - on_us;
	for (int e = 0; e < ms * 1000; e += SEG_PWM_PERIOD_US) {
		seg_set(mask);
		k_usleep(on_us);
		seg_set(0);
		k_usleep(off_us);
	}
}

/*
 * Drive all four digit-enables LOW as early as possible. The 7-seg is always
 * powered from +4.6V; until firmware actively holds these lines low they float
 * (after reset they're high-Z inputs), and a transient in the ~150ms before the
 * animation thread starts can briefly flash a digit. Clamp them off at boot.
 */
static int segment_pins_off(void)
{
	if (device_is_ready(gpio1)) {
		for (int d = 0; d < N_DIG; d++) {
			gpio_pin_configure(gpio1, SEG_FIRST + d, GPIO_OUTPUT_LOW);
		}
		seg_set(0);
	}
	return 0;
}
SYS_INIT(segment_pins_off, POST_KERNEL, 50);

/* ─── animation thread ────────────────────────────────────────────────────── */

static void segment_thread(void *a, void *b, void *c)
{
	ARG_UNUSED(a);
	ARG_UNUSED(b);
	ARG_UNUSED(c);

	if (!device_is_ready(gpio1)) {
		LOG_ERR("gpio1 not ready — no 7-seg");
		return;
	}

	for (int d = 0; d < N_DIG; d++) {
		gpio_pin_configure(gpio1, SEG_FIRST + d, GPIO_OUTPUT_LOW);
	}

	/* ── boot fade-in: each digit ramps up, left to right (to the dim steady
	 * level, so it settles straight into the low-power brightness) ── */
	for (int d = 0; d < N_DIG; d++) {
		bright[d] = 0;
	}
	for (int d = 0; d < N_DIG; d++) {
		for (int level = 1; level <= SEG_STEADY_LEVEL; level++) {
			bright[d] = level;
			pwm_render(FADE_STEP_FRAMES);
		}
	}
	LOG_INF("7-seg faded in -> 2026 (dimmed), glitch animation running");

	/* ── perpetual glitch loop — every shown state is PWM-dimmed via seg_show ── */
	uint32_t s = (k_uptime_get_32() * 2654435761u) ^ 0x20260c0d;

	for (;;) {
		s = s * 1664525u + 1013904223u;
		uint32_t r = s >> 8;

		if ((r & 7u) != 0u) {
			/* calm: all digits on for a beat */
			seg_show(SEG_MASK, 120 + (r % 420));
			continue;
		}

		/* glitch burst — biased toward DOUBLE glitches (looks most real) */
		uint32_t bsel = (r >> 16) & 7u;
		int burst = (bsel < 1) ? 1 : (bsel < 6) ? 2 : 3;   /* ~1/8, ~5/8, ~2/8 */

		for (int g = 0; g < burst; g++) {
			s = s * 1664525u + 1013904223u;
			uint32_t gr = s >> 8;

			switch (gr & 3u) {
			case 0: {   /* a single digit drops out briefly */
				int d = (gr >> 5) % N_DIG;
				seg_show(SEG_MASK & ~BIT(SEG_FIRST + d), 30 + (gr % 90));
				break;
			}
			case 1: {   /* a digit stutters on/off */
				int d = (gr >> 5) % N_DIG;
				for (int i = 0; i < 6; i++) {
					seg_show((i & 1) ? SEG_MASK
							 : (SEG_MASK & ~BIT(SEG_FIRST + d)),
						 25);
				}
				break;
			}
			case 2:     /* whole display blinks out */
				seg_show(0, 20 + (gr % 60));
				break;
			default: {  /* a few random digit patterns flash by */
				uint32_t t = gr;
				for (int i = 0; i < 4; i++) {
					seg_show(t & SEG_MASK, 40);
					t = t * 1664525u + 1013904223u;
				}
				break;
			}
			}

			if (g + 1 < burst) {
				seg_show(SEG_MASK, 15 + ((s >> 5) % 40));  /* tight pair gap */
			}
		}

		/* after a burst, sometimes a digit (or two) lingers OFF for ~1s */
		s = s * 1664525u + 1013904223u;
		if (((s >> 9) % 3u) == 0u) {
			uint32_t off = BIT(SEG_FIRST + ((s >> 5) % N_DIG));
			if ((s >> 11) & 1u) {
				off |= BIT(SEG_FIRST + ((s >> 13) % N_DIG));
			}
			seg_show(SEG_MASK & ~off, 700 + ((s >> 3) % 700));   /* ~0.7-1.4 s */
		}
	}
}

#define SEG_STACK 768
K_THREAD_DEFINE(segment_tid, SEG_STACK, segment_thread, NULL, NULL, NULL,
		K_PRIO_PREEMPT(12), 0, 150);
