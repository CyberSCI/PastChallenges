#pragma once

#include <stdint.h>

/*
 * Mainframe node: advertises a famous-computer name (per provisioned index
 * 0..9) and exposes a GATT service:
 *   NODE_TYPE (read)  -> the system name
 *   AUTH      (write) -> the password; correct value unlocks FRAGMENT
 *   FRAGMENT  (read)  -> the 32-byte Shamir share (gated by AUTH)
 */

/* Mount NVS, load provisioned index, enable BLE, start advertising + GATT. */
void node_start(void);

uint8_t node_get_index(void);

/* Re-provision identity 0..9 (persists to NVS, re-advertises). -1 on error. */
int node_set_index(uint8_t idx);
