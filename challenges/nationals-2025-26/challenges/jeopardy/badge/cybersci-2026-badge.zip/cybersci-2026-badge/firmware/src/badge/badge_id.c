#include "badge_id.h"

#include <zephyr/kernel.h>
#include <zephyr/drivers/hwinfo.h>
#include <zephyr/logging/log.h>
#include <stdio.h>

LOG_MODULE_REGISTER(badge_id, LOG_LEVEL_INF);

static uint8_t  badge_type;
static uint64_t badge_uid;
static char     ble_name[12];   /* "SRVNODE-N\0" fits in 10, pad to 12 */

static int badge_id_sys_init(void)
{
	uint8_t raw[8];
	ssize_t len = hwinfo_get_device_id(raw, sizeof(raw));

	if (len <= 0) {
		LOG_WRN("hwinfo_get_device_id failed (%zd); defaulting to type 0", len);
		badge_uid  = 0;
		badge_type = 0;
	} else {
		badge_uid = 0;
		for (int i = 0; i < len && i < 8; i++) {
			badge_uid |= ((uint64_t)raw[i] << (i * 8));
		}
		badge_type = (uint8_t)(badge_uid % BADGE_TYPE_COUNT);
	}

	snprintf(ble_name, sizeof(ble_name), "SRVNODE-%u", badge_type);

	LOG_INF("Badge UID=0x%016llx  type=%u  BLE name=%s",
		(unsigned long long)badge_uid, badge_type, ble_name);
	return 0;
}

/*
 * Initialise before BLE and shell (both also use APPLICATION level but at
 * higher priority numbers, so they run after this).
 */
SYS_INIT(badge_id_sys_init, APPLICATION, 10);

uint8_t badge_id_get_type(void)       { return badge_type; }
uint64_t badge_id_get_uid(void)       { return badge_uid;  }
const char *badge_id_get_ble_name(void) { return ble_name; }
