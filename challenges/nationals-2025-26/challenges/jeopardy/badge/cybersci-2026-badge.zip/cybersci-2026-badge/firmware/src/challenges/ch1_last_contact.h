#pragma once

/* Start Ch1: begin Morse LED loop and arm DIP-switch monitor. */
void ch1_start(void);

/* The Ch1 flag (for `status` to re-print after a power-cycle auto-unlock). */
const char *ch1_flag(void);
