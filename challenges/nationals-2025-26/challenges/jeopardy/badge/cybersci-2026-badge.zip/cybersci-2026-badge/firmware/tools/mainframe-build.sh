#!/bin/bash
# Build the MAINFRAME firmware (upstream Zephyr 3.7 + gnuarmemb).
# Output: ~/mainframebuild/zephyr/zephyr.hex   (build dir kept on local fs, not the share)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC="$(cd "$SCRIPT_DIR/.." && pwd)"                  # firmware/
export PATH="$HOME/zephyr-venv/bin:$PATH"
export ZEPHYR_TOOLCHAIN_VARIANT=gnuarmemb
export GNUARMEMB_TOOLCHAIN_PATH=/usr
export ZEPHYR_BASE="$HOME/zephyrproject/zephyr"
west build -b nrf52840dk/nrf52840 -d "$HOME/mainframebuild" "$SRC/mainframe" "$@"
