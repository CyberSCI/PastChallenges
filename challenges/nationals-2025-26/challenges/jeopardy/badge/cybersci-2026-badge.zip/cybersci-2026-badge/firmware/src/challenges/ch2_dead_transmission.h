#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <zephyr/shell/shell.h>

/*
 * Ch2 "Dead Transmission" - collect Shamir shares from the 10 mainframe nodes.
 *
 * Each mainframe (organizer-worn badge) advertises a famous-computer name and
 * serves a 32-byte fragment once its password is written to AUTH. The player
 * reads the fragment over BLE (phone) and submits it here with `key <name>`.
 * Any CH2_THRESHOLD (7) of the 10 shares reconstruct the flag.
 */

/* Resolve a node name (case-insensitive, e.g. "wopr", "deep thought") to its
 * index 0..9, or -1 if unknown. */
int         ch2_node_index(const char *name);
const char *ch2_node_name_of(uint8_t index);

/*
 * Validate a submitted 64-hex-char (32-byte) fragment against node `index`'s
 * known CRC and store it. Returns true if well-formed and correct.
 */
bool ch2_accept_key(uint8_t index, const char *hex_str);

/*
 * If at least CH2_THRESHOLD fragments are stored, Shamir-reconstruct the flag,
 * verify it, print it, mark Ch2 solved, and bring the radio online (Ch3).
 * Prints progress and returns false if below threshold or verification fails.
 */
bool ch2_decrypt(const struct shell *sh);

/*
 * Reconstruct the Ch2 flag from the stored fragments into `out` (needs
 * CH2_FRAG_LEN+1 bytes). Returns false if below threshold or verification
 * fails. Lets `status` re-show the flag after a power-cycle.
 */
bool ch2_get_flag(char *out, size_t out_sz);

/* Length of the LED strip (mirrors LED_COUNT in led.c) used for the bar. */
#define CH2_STRIP_LEN 20

/*
 * Map the number of fragments keyed in to a 0..CH2_STRIP_LEN green-pixel
 * count for led_progress(): full strip once the threshold is reached.
 */
uint8_t ch2_progress_pixels(void);
