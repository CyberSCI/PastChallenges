#pragma once

#include <zephyr/shell/shell.h>

/*
 * Sign message with ECDSA using the badge's private key and broken LCG PRNG.
 * Prints r and s as hex to sh.
 */
int ch3_sign(const struct shell *sh, const char *message);

/*
 * Verify an ECDSA signature. r_hex and s_hex are big-endian hex strings.
 * Prints VALID or INVALID to sh.
 */
int ch3_verify(const struct shell *sh, const char *message,
	       const char *r_hex, const char *s_hex);

/*
 * Print several consecutive LCG RNG samples to sh.
 * Visible only after Ch2 - this is the Ch3 discovery hint.
 */
void ch3_rng_sample(const struct shell *sh);
