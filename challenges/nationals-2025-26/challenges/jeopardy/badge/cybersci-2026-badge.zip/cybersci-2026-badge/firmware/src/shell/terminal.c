#include "terminal.h"

#include <zephyr/kernel.h>
#include <zephyr/shell/shell.h>
#include <zephyr/shell/shell_uart.h>   /* shell_backend_uart_get_ptr() */
#include <zephyr/logging/log.h>

#include "badge/badge_id.h"
#include "badge/state.h"
#include "challenges/ch3_transmission.h"

LOG_MODULE_REGISTER(terminal, LOG_LEVEL_DBG);

/*
 * Shell prompts. The "online" prompt is green via ANSI - but note Zephyr's
 * shell measures prompt width with a plain strlen (z_shell_strlen), so the
 * invisible escape bytes inflate its cursor/line-wrap math. We therefore only
 * colour the prompt AFTER the transmitter is online, by which point the player
 * is done entering the long 64-hex `key` lines (only short commands remain),
 * so the miscount can't corrupt line editing in practice.
 */
#define PROMPT_KEYING "badge> "
#define PROMPT_ONLINE "\x1b[1;32mbadge>\x1b[0m "

/*
 * The serial shell instance (SHELL_DEFINE(shell_uart, ...) in
 * subsys/shell/backends/shell_uart.c) is file-static, so we reach it through
 * the public accessor shell_backend_uart_get_ptr() rather than an extern.
 * With CONFIG_SHELL_BACKEND_SERIAL and chosen zephyr,shell-uart = &cdc_acm_uart0
 * this one instance runs the shell over USB CDC-ACM.  (NCS instead ships a
 * dedicated shell_cdc_acm backend.)
 */

/* ─── Pre-Ch1 scrambled display ──────────────────────────────────────────── */

static struct k_work_delayable scramble_work;
static uint32_t                scramble_seq;

/*
 * Thematic lines that cycle in between hex-noise rows.
 * They look like a corrupted radio terminal, fitting the post-apoc theme.
 */
static const char *const thematic_lines[] = {
	"[SYS] CARRIER SIGNAL LOST ... SCANNING ...",
	"[ERR] SYNC FAILURE  - CHANNEL NOT LOCKED",
	"[RCV] 01101000 01100101 10001101 01111000 ...",
	">>>  AWAITING FREQUENCY CALIBRATION  <<<",
	"[SYS] LAST KNOWN CHANNEL: ???.???  kHz",
	"=====  SIGNAL: NONE  =====  BER: 100%  =====",
	">>>  TUNE RECEIVER TO LAST CONTACT POINT  <<<",
	"[ERR] FRAME SLIP  - RESYNCHRONISING ...",
};
static int thematic_idx;

static void print_noise_line(void)
{
	/*
	 * Knuth multiplicative LCG seeded with badge UID so every badge
	 * shows its own unique noise pattern.
	 */
	uint32_t s = scramble_seq++ ^ (uint32_t)badge_id_get_uid();
	char buf[48];
	int  pos = 0;

	for (int i = 0; i < 8 && pos < (int)sizeof(buf) - 6; i++) {
		s = s * 1664525u + 1013904223u;
		pos += snprintf(buf + pos, sizeof(buf) - pos,
				"%04X ", (unsigned)(s >> 16));
	}
	printk("%s\r\n", buf);
}

static void scramble_fn(struct k_work *work)
{
	ARG_UNUSED(work);

	if ((scramble_seq % 5) == 0) {
		printk("%s\r\n",
		       thematic_lines[thematic_idx %
				      ARRAY_SIZE(thematic_lines)]);
		thematic_idx++;
	} else {
		print_noise_line();
	}

	k_work_schedule(&scramble_work, K_MSEC(250));
}

static void swallow_bypass(const struct shell *sh, uint8_t *data, size_t len)
{
	ARG_UNUSED(sh);
	ARG_UNUSED(data);
	ARG_UNUSED(len);
	/* All terminal input is silently discarded until Ch1 is solved. */
}

/* ─── SYS_INIT: runs after shell (priority 90), before main() ────────────── */

static int terminal_sys_init(void)
{
	k_work_init_delayable(&scramble_work, scramble_fn);

	if (state_ch2_is_solved()) {
		/* Transmitter already online from a previous session - green prompt. */
		shell_prompt_change(shell_backend_uart_get_ptr(), PROMPT_ONLINE);
	} else if (state_ch1_is_solved()) {
		shell_prompt_change(shell_backend_uart_get_ptr(), PROMPT_KEYING);
	} else {
		/*
		 * Suppress the prompt and swallow all input now, before USB is
		 * enabled (main() hasn't run yet).  terminal_start_scramble()
		 * is called from main() once DTR is asserted to start the
		 * visible noise output.
		 */
		shell_prompt_change(shell_backend_uart_get_ptr(), "");
		shell_set_bypass(shell_backend_uart_get_ptr(), swallow_bypass);
	}

	return 0;
}

/*
 * Priority 91 - must be > CONFIG_SHELL_INIT_PRIORITY (90) so the shell
 * backend exists before we touch it.
 */
SYS_INIT(terminal_sys_init, APPLICATION, 91);

/* ─── Public API ──────────────────────────────────────────────────────────── */

void terminal_start_scramble(void)
{
	k_work_schedule(&scramble_work, K_MSEC(200));
}

void terminal_unlock(const char *flag)
{
	k_work_cancel_delayable_sync(&scramble_work,
				     &(struct k_work_sync){});

	/* ANSI: clear screen, cursor home */
	printk("\033[2J\033[H");

	printk("============================================\r\n");
	printk("  CHANNEL LOCKED - SIGNAL ACQUIRED\r\n");
	printk("============================================\r\n");
	printk("\r\n");
	printk("  %s\r\n", flag);
	printk("\r\n");
	printk("  -- CHANNEL CARD --\r\n");
	ch3_channel_card(NULL);
	printk("\r\n");
	printk("  System online.  Type 'help' for commands.\r\n");
	printk("============================================\r\n\r\n");

	shell_prompt_change(shell_backend_uart_get_ptr(), PROMPT_KEYING);
	shell_set_bypass(shell_backend_uart_get_ptr(), NULL);
}

void terminal_prompt_online(void)
{
	/* Switch to the green "transmitter online" prompt. */
	shell_prompt_change(shell_backend_uart_get_ptr(), PROMPT_ONLINE);
}

const struct shell *terminal_get_shell(void)
{
	return shell_backend_uart_get_ptr();
}
