#pragma once

#include <stdint.h>

#define BADGE_TYPE_COUNT 10   /* number of distinct badge types (0–9) */

/*
 * Badge type: 0–9, derived from the nRF52840 FICR hardware UID.
 * Computed once at boot via SYS_INIT; safe to read from any context.
 *
 *   badge_type = lower 64 bits of FICR.DEVICEID % 10
 *
 * All 50 badges run identical firmware; this value drives BLE advertising
 * name, GATT fragment selection, and unlock key for Ch2.
 */
uint8_t     badge_id_get_type(void);
uint64_t    badge_id_get_uid(void);
const char *badge_id_get_ble_name(void);   /* e.g. "SRVNODE-3" */
