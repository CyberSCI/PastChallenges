#include "dip_switch.h"

#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(dip_switch, LOG_LEVEL_DBG);

static const struct gpio_dt_spec dip_pins[8] = {
	GPIO_DT_SPEC_GET(DT_NODELABEL(dip0), gpios),
	GPIO_DT_SPEC_GET(DT_NODELABEL(dip1), gpios),
	GPIO_DT_SPEC_GET(DT_NODELABEL(dip2), gpios),
	GPIO_DT_SPEC_GET(DT_NODELABEL(dip3), gpios),
	GPIO_DT_SPEC_GET(DT_NODELABEL(dip4), gpios),
	GPIO_DT_SPEC_GET(DT_NODELABEL(dip5), gpios),
	GPIO_DT_SPEC_GET(DT_NODELABEL(dip6), gpios),
	GPIO_DT_SPEC_GET(DT_NODELABEL(dip7), gpios),
};

static struct gpio_callback    dip_cb_data;
static dip_change_cb_t         user_cb;
static struct k_work_delayable debounce_work;

static void debounce_fn(struct k_work *work)
{
	ARG_UNUSED(work);
	if (user_cb) {
		user_cb(dip_switch_read());
	}
}

static void gpio_isr(const struct device *dev, struct gpio_callback *cb,
		     gpio_port_pins_t pins)
{
	ARG_UNUSED(dev);
	ARG_UNUSED(cb);
	ARG_UNUSED(pins);
	k_work_reschedule(&debounce_work, K_MSEC(20));
}

static int dip_switch_sys_init(void)
{
	k_work_init_delayable(&debounce_work, debounce_fn);

	gpio_port_pins_t pin_mask = 0;

	for (int i = 0; i < 8; i++) {
		if (!gpio_is_ready_dt(&dip_pins[i])) {
			LOG_ERR("DIP pin %d not ready", i);
			return -ENODEV;
		}
		gpio_pin_configure_dt(&dip_pins[i], GPIO_INPUT);
		gpio_pin_interrupt_configure_dt(&dip_pins[i], GPIO_INT_EDGE_BOTH);
		pin_mask |= BIT(dip_pins[i].pin);
	}

	/*
	 * All 8 pins are on gpio1 (P1.01–P1.08), so one shared callback
	 * covers them all. dip_pins[0].port is &gpio1.
	 */
	gpio_init_callback(&dip_cb_data, gpio_isr, pin_mask);
	gpio_add_callback(dip_pins[0].port, &dip_cb_data);

	LOG_INF("DIP switches ready, initial state: 0x%02x", dip_switch_read());
	return 0;
}

SYS_INIT(dip_switch_sys_init, APPLICATION, 20);

uint8_t dip_switch_read(void)
{
	uint8_t state = 0;

	/*
	 * The player spells the channel's binary on the switch bank starting at
	 * the first switch (P1.01) as the MSB. dip_pins[0] is P1.01, so map it to
	 * bit 7 and count down -- otherwise the firmware reads the pattern in
	 * reverse bit order. Combined with ACTIVE_HIGH (see board overlay) a switch
	 * in the "1" position now contributes a literal 1 in reading order.
	 */
	for (int i = 0; i < 8; i++) {
		if (gpio_pin_get_dt(&dip_pins[i]) > 0) {
			state |= BIT(7 - i);
		}
	}
	return state;
}

void dip_switch_set_callback(dip_change_cb_t cb)
{
	user_cb = cb;
}
