#pragma once
/* All commands self-register via SHELL_CMD_REGISTER in commands.c */
