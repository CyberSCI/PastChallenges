#include <zephyr/kernel.h>
#include <zephyr/shell/shell.h>
#include <zephyr/logging/log.h>
#include <string.h>
#include <stdlib.h>

#include "badge/badge_id.h"
#include "badge/state.h"
#include "hw/led.h"
#include "challenges/ch1_last_contact.h"
#include "challenges/ch2_dead_transmission.h"
#include "challenges/ch3_transmission.h"
#include "challenges/ch3_broken_trust.h"
#include "gen/ch2_player_data.h"   /* CH2_NODE_COUNT / CH2_THRESHOLD */

LOG_MODULE_REGISTER(commands, LOG_LEVEL_DBG);

#define ADMIN_PASS "REBUILD2026"

/* ─── Gate macro ──────────────────────────────────────────────────────────── */

/*
 * Every command that should only be accessible after Ch1 starts with this.
 * The scrambled-output phase uses shell_set_bypass to swallow all input, so
 * in practice this gate is never hit during scramble mode - it's a safety net
 * for edge cases (e.g. badge power-cycled with Ch1 already solved).
 */
#define REQUIRE_CH1(sh) \
	do { \
		if (!state_ch1_is_solved()) { \
			shell_print(sh, "..."); \
			return -EACCES; \
		} \
	} while (0)

/* ─── help ────────────────────────────────────────────────────────────────── */

/*
 * Custom help - CONFIG_SHELL_HELP=n disables the built-in version so we can
 * gate `rng` from the listing until Ch2 is solved.
 */
static int cmd_help(const struct shell *sh, size_t argc, char **argv)
{
	ARG_UNUSED(argc);
	ARG_UNUSED(argv);

	REQUIRE_CH1(sh);

	shell_print(sh, "Transceiver control:");
	shell_print(sh, "  help                      This message");
	shell_print(sh, "  status                    Transceiver status");
	shell_print(sh, "  key <node> <hex>          Key in a fragment from a mainframe");
	shell_print(sh, "                            e.g. key wopr <64-hex-chars>");
	shell_print(sh, "  (the transmitter locks on automatically once enough");
	shell_print(sh, "   channel keys are loaded)");

	if (state_ch2_is_solved()) {
		shell_print(sh, "  -- TRANSMITTER ONLINE: your badge is on the air --");
	}

	return 0;
}

SHELL_CMD_REGISTER(help, NULL, "List available commands", cmd_help);

/* ─── status ──────────────────────────────────────────────────────────────── */

static int cmd_status(const struct shell *sh, size_t argc, char **argv)
{
	ARG_UNUSED(argc);
	ARG_UNUSED(argv);

	REQUIRE_CH1(sh);

	shell_print(sh, "Transceiver status");
	shell_print(sh, "------------------");

	/* Tuning (Ch1) - always solved if we got here; re-show the flag in case
	 * the badge auto-locked at power-on and the player missed the banner. */
	shell_print(sh, "  Tuning      : LOCKED   %s", ch1_flag());

	/* Keying (Ch2) - fragments collected toward the threshold. */
	shell_print(sh, "  Keying      : %u/%u fragments keyed (need %u)",
		    state_fragment_count(), CH2_NODE_COUNT, CH2_THRESHOLD);

	if (state_ch2_is_solved()) {
		char flag[CH2_FRAG_LEN + 1];
		if (ch2_get_flag(flag, sizeof(flag))) {
			shell_print(sh, "                DECODED  %s", flag);
		} else {
			shell_print(sh, "                DECODED");
		}
	}

	/* Transmitter (Ch3) - on the air once the transmission is decoded. */
	shell_print(sh, "  Transmitter : %s",
		    state_ch2_is_solved() ? "ONLINE - broadcasting" : "offline");

	/* Channel card - the player's own station callsign + decode key group. */
	shell_print(sh, "");
	shell_print(sh, "Channel card (your station):");
	ch3_channel_card(sh);

	return 0;
}

SHELL_CMD_REGISTER(status, NULL, "Show challenge progress", cmd_status);

/* ─── key <type> <hex> ────────────────────────────────────────────────────── */

static int cmd_key(const struct shell *sh, size_t argc, char **argv)
{
	REQUIRE_CH1(sh);

	if (argc < 3) {
		shell_print(sh, "Usage: key <node> <64-hex-char fragment>");
		shell_print(sh, "  e.g. key wopr <hex>   "
				"(multi-word ok: key deep thought <hex>)");
		return -EINVAL;
	}

	/* Last arg is the hex fragment; everything between is the node name. */
	const char *hex = argv[argc - 1];

	char name[40];
	size_t pos = 0;
	for (size_t i = 1; i < argc - 1; i++) {
		int w = snprintf(name + pos, sizeof(name) - pos, "%s%s",
				 i > 1 ? " " : "", argv[i]);
		if (w < 0 || (size_t)w >= sizeof(name) - pos) {
			break;
		}
		pos += w;
	}

	int idx = ch2_node_index(name);
	if (idx < 0) {
		shell_print(sh, "Unknown node '%s'.", name);
		return -EINVAL;
	}

	if (state_has_fragment((uint8_t)idx)) {
		shell_print(sh, "Fragment from %s already logged.",
			    ch2_node_name_of((uint8_t)idx));
		return 0;
	}

	if (!ch2_accept_key((uint8_t)idx, hex)) {
		shell_print(sh, "Rejected - bad fragment for %s.",
			    ch2_node_name_of((uint8_t)idx));
		return -EINVAL;
	}

	shell_print(sh, "Fragment from %s keyed in.  [%u/%u, need %u]",
		    ch2_node_name_of((uint8_t)idx), state_fragment_count(),
		    CH2_NODE_COUNT, CH2_THRESHOLD);

	/* Advance the green "charging" bar by one segment for the new fragment. */
	led_progress(ch2_progress_pixels());

	/* Enough channel keys loaded - the transmitter locks the signal and comes
	 * on the air automatically (no separate decode step). Every fragment was
	 * CRC-checked on entry, so >= threshold always reconstructs cleanly. */
	if (!state_ch2_is_solved() && state_fragment_count() >= CH2_THRESHOLD) {
		ch2_decrypt(sh);
	}

	return 0;
}

SHELL_CMD_ARG_REGISTER(key, NULL, "Key in a fragment from a mainframe",
		       cmd_key, 3, 8);

/* ─── sign <message> ──────────────────────────────────────────────────────── */

static int cmd_sign(const struct shell *sh, size_t argc, char **argv)
{
	REQUIRE_CH1(sh);

	if (argc != 2) {
		shell_print(sh, "Usage: sign <message>");
		return -EINVAL;
	}

	return ch3_sign(sh, argv[1]);
}

SHELL_CMD_ARG_REGISTER(sign, NULL, "ECDSA-sign a message (Ch3)", cmd_sign, 2, 0);

/* ─── verify <message> <r> <s> ───────────────────────────────────────────── */

static int cmd_verify(const struct shell *sh, size_t argc, char **argv)
{
	REQUIRE_CH1(sh);

	if (argc != 4) {
		shell_print(sh, "Usage: verify <message> <r_hex> <s_hex>");
		return -EINVAL;
	}

	return ch3_verify(sh, argv[1], argv[2], argv[3]);
}

SHELL_CMD_ARG_REGISTER(verify, NULL, "Verify ECDSA signature (Ch3)",
		       cmd_verify, 4, 0);

/* ─── rng (hidden until Ch2 solved) ──────────────────────────────────────── */

static int cmd_rng(const struct shell *sh, size_t argc, char **argv)
{
	ARG_UNUSED(argc);
	ARG_UNUSED(argv);

	REQUIRE_CH1(sh);

	if (!state_ch2_is_solved()) {
		/* Not in help yet; give nothing away */
		return -ENOENT;
	}

	ch3_rng_sample(sh);
	return 0;
}

/*
 * Registered with NULL help string so it is omitted by our custom help handler
 * before Ch2 is solved.  (SHELL_CMD_REGISTER always makes a command callable
 * by name - the custom help function controls whether it's listed.)
 */
SHELL_CMD_REGISTER(rng, NULL, NULL, cmd_rng);

/* ─── admin <password> (never in help) ───────────────────────────────────── */

static int cmd_admin(const struct shell *sh, size_t argc, char **argv)
{
	if (argc != 2 || strcmp(argv[1], ADMIN_PASS) != 0) {
		/* Give nothing away - look like an unknown command */
		return -ENOENT;
	}

	shell_print(sh, "--- ADMIN ---");
	shell_print(sh, "Badge UID  : 0x%016llx",
		    (unsigned long long)badge_id_get_uid());
	shell_print(sh, "Badge type : %u", badge_id_get_type());
	shell_print(sh, "State flags: 0x%04x", (unsigned)(
		    (state_ch1_is_solved()  ? STATE_CH1_SOLVED  : 0) |
		    (state_ch2_is_solved()  ? STATE_CH2_SOLVED  : 0) |
		    (state_ch3_is_solved()  ? STATE_CH3_SOLVED  : 0)));
	shell_print(sh, "Frag mask  : 0x%04x", state_fragment_mask());

	if (argc > 2 && strcmp(argv[2], "reset") == 0) {
		state_reset();
		shell_print(sh, "State cleared.  Reboot to re-run Ch1.");
	}

	return 0;
}

SHELL_CMD_ARG_REGISTER(admin, NULL, NULL, cmd_admin, 2, 1);
